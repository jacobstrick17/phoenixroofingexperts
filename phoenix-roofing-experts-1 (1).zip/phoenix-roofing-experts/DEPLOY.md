# Deploy Guide — Phoenix Roofing Experts

Connecting the built site to `phoenixroofingcontractors.info`.

The repo is already initialized with a first commit. Three pieces get connected:
GitHub (stores the code) → Netlify (serves it) → Squarespace (owns the domain).

---

## 1. Push to GitHub

Create a new **empty** repo at [github.com/new](https://github.com/new) — no README,
no .gitignore, no license, or the first push will conflict. Private is fine.

Then, from the project folder:

```bash
git remote add origin https://github.com/YOUR-USERNAME/phoenix-roofing-experts.git
git branch -M main
git push -u origin main
```

`crm/.env` is gitignored, so your Supabase key is not pushed. You'll paste those two
values into Netlify's dashboard instead (step 4).

---

## 2. Deploy the website

At [app.netlify.com](https://app.netlify.com): **Add new site → Import an existing
project → GitHub →** pick the repo.

| Setting | Value |
|---|---|
| Base directory | `site` |
| Build command | *(leave empty)* |
| Publish directory | `site` |

Base directory `site` is the important one — it makes Netlify treat that folder as the
web root. Every link on the site is root-relative (`/css/style.css`,
`/services/roof-repair.html`), so if the root is wrong you get a broken page or a
directory listing. `site/netlify.toml` handles the rest: clean URLs, the custom 404,
cache and security headers.

You'll get a URL like `curious-otter-a1b2c3.netlify.app`. **Test it fully before
touching DNS** — click through the city pages, submit a real lead, confirm the 404
works. Fixing problems here is far easier than on the live domain.

---

## 3. Point the domain

### In Netlify

Site configuration → Domain management → **Add a domain** →
`phoenixroofingcontractors.info`. Netlify will display the exact DNS records it wants.
**Use the values Netlify shows you**, not the ones below — they're the current
defaults and can change.

Typically:

| Type | Name / Host | Value |
|---|---|---|
| A | `@` | `75.2.60.5` |
| CNAME | `www` | `your-site-name.netlify.app` |

### In Squarespace

Go to [account.squarespace.com/domains](https://account.squarespace.com/domains) →
click the domain → **DNS** → **DNS Settings** → add the custom records above.

**Add records — do not switch nameservers.** Squarespace offers a "Domain
Nameservers → Use Custom Nameservers" option, and you don't want it. Switching
nameservers wipes your existing DNS records, disconnects any Google Workspace email
on the domain, and takes up to 48 hours to propagate. Adding two records does the
same job with none of that.

DNS usually resolves within minutes. Netlify then issues a free SSL certificate
automatically — wait for the padlock before announcing the site anywhere. Browsers
label plain HTTP as "Not secure," which is a poor first impression for a contractor
asking to get on someone's roof.

---

## 4. Deploy the CRM

A **separate** Netlify site from the same repo. Add new site → same repo, then:

| Setting | Value |
|---|---|
| Base directory | `crm` |
| Build command | `npm run build` |
| Publish directory | `dist` |

Then Site configuration → Environment variables → add both:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Copy the values from your local `crm/.env`. Redeploy after adding them — Vite bakes
env vars in at build time, so a build that ran before you added them won't pick them up.

Leave it on the `.netlify.app` URL or give it a subdomain like
`crm.phoenixroofingcontractors.info`. **Don't link to it from the public site.**

---

## 5. Lock down Supabase

Two settings in the [Supabase dashboard](https://supabase.com/dashboard/project/bghvhowpwbicojgwwirx).

**Turn off public signups first.** Authentication → Sign In / Providers → Email →
disable **"Allow new users to sign up"**. The database grants access to any
*authenticated* user, so if self-signup stays on, anyone who finds the CRM URL can
create an account and read every customer record. This step is what makes the login
meaningful.

**Then create your user.** Authentication → Users → **Add user** → Create new user.
Use a real address so password reset works. Repeat for each staff member.

---

## 6. Verify

- [ ] Homepage loads over **https://** with a padlock
- [ ] All five city pages load
- [ ] A wrong URL shows the custom 404, not Netlify's default
- [ ] Submit a real lead on the live domain → it appears on the CRM pipeline
- [ ] CRM redirects to login when signed out
- [ ] Add the **website URL** to your Google Business Profile
- [ ] Submit `https://www.phoenixroofingcontractors.info/sitemap.xml` in
      [Google Search Console](https://search.google.com/search-console) — this is how
      the city pages get discovered quickly instead of waiting to be crawled

---

## Updating the site later

```bash
cd site
python3 generate_site.py     # after editing constants or copy
cd ..
git add -A && git commit -m "Update site" && git push
```

Netlify rebuilds automatically on every push.
