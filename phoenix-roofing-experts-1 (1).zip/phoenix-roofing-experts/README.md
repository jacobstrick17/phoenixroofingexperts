# Phoenix Roofing Experts — Website + CRM

**Powered by Sun & Shield Construction and Roofing — Arizona ROC #366348**

This project has two independent pieces that share one Supabase database:

1. **`/site`** — a static, SEO-optimized marketing website (plain HTML/CSS/JS, no build step).
2. **`/crm`** — a private React CRM app (pipeline, contacts, tasks, activity timeline) for your team.

When someone submits the "Get a Free Estimate" form on the website, it writes directly to the
`contacts` table in Supabase. A database trigger automatically creates a "New Lead" deal, which
shows up instantly on the CRM's Pipeline board — no manual entry, no Zapier, no extra service.

## Live backend

- **Supabase project:** `phoenix-roofing-experts` (project ref `bghvhowpwbicojgwwirx`)
  (project name kept as-is — renaming it would change nothing functionally and would break the saved URLs)
- **Dashboard:** https://supabase.com/dashboard/project/bghvhowpwbicojgwwirx
- Both the website's contact form and the CRM app are already wired to this project using its
  public **anon key** (safe to expose in client-side code — see the Security section below).

## What to customize before launch

Everything below lives in the constants block at the top of `site/generate_site.py`.
Edit there, then re-run `python3 generate_site.py` to rebuild every page at once.

| What | Current value | Status |
|---|---|---|
| `SITE_NAME` | Phoenix Roofing Experts | ✅ set — **must match the Google Business Profile name** |
| `POWERED_BY` | Sun & Shield Construction and Roofing | ✅ set |
| `ROC_LICENSE` | ROC #366348 | ✅ set — verify at [roc.az.gov](https://roc.az.gov/search) |
| `PHONE_DISPLAY` / `PHONE_TEL` | (480) 331-1017 | ✅ set — Google Voice |
| `EMAIL` | `None` — no public email by choice | ✅ set |
| `DOMAIN` | www.phoenixroofingcontractors.info | ✅ set |
| Reviews | 2 real Google reviews live | ✅ set |

### Business name consistency (don't change this casually)

`SITE_NAME` is **Phoenix Roofing Experts** because that is the name on the Google
Business Profile. Google uses name/website consistency to decide whether a listing
and a site are the same business, so a mismatch works directly against the local
rankings the city pages are built for.

If the real-world name ever changes — trucks, signage, paperwork — change the
profile and the site together, not one of them. Renaming an established profile
can trigger re-verification, and Google requires the profile name to match
real-world branding, so a rename that doesn't match can be rejected or flagged.

### About the domain

The domain is `phoenixroofingcontractors.info` while the brand on the site is
Phoenix Roofing Experts. That mismatch is fine, and it's the right trade: of the
three name signals, the one Google actually weighs is **profile name vs. site
name**, and those match. Domain names carry little ranking weight on their own —
exact-match domains stopped being a meaningful signal years ago.

Two things to be aware of anyway:

- **Visitor confusion.** Someone clicking `phoenixroofingcontractors.info` lands on
  a site called Phoenix Roofing Experts. Most people won't notice; some will. If a
  `.com` on the matching name is ever available, it's worth grabbing and 301
  redirecting.
- **`.info` reads as less established than `.com`** to a lot of homeowners. Google
  treats generic TLDs equally, so this isn't a ranking issue — it's a click-through
  and trust issue, and it matters more for a contractor asking to get on someone's
  roof than it would for most businesses.

Neither is worth delaying launch over. Ship on this domain and upgrade later if a
better one opens up — the `DOMAIN` constant plus a re-run is the entire migration
on the site's side.

### The phone number

`PHONE_DISPLAY` and `PHONE_TEL` must be updated **together** — the first is what
visitors read, the second is the `tel:` link they tap on mobile. A `555` number is
the placeholder so it can never be mistaken for a live line. Set both and re-run
`generate_site.py`; the number propagates to the header bar, every hero CTA, both
footers, and the contact page automatically.

The live number is a **Google Voice** line: (480) 331-1017. Calls forward to your
mobile, your personal number stays private, and you get voicemail transcription.

**Put this same number on the Google Business Profile.** Matching phone numbers
between the profile and the site is part of what tells Google they're one business.
One caveat: Google Voice numbers are VoIP, and changing the phone on an established
profile can trigger re-verification — change it once, on a weekday, and be ready to
re-verify if asked.

Two things Google Voice won't do that matter later: it won't tell you which page or
ad a call came from, and it has no call recording or routing rules. Swap in Twilio
when you have ID — it's a one-line change here plus forwarding setup on their end.

### No public email address

`EMAIL` is set to `None`, so no email address and no `mailto:` link appears anywhere
on the site. Leads arrive two ways only: a phone call/text to (480) 331-1017, or the
estimate form.

Because of that, **phone is a required field on every form** and email is optional.
An email-only lead would be one you have no fast way to reach, and roofing leads go
cold quickly — especially active leaks.

To bring email back later, set `EMAIL` to a real address and re-run the script. The
footer and contact page links return automatically; you'd also want to loosen the
`required` on the phone input in `lead_form()` and the matching check in
`js/main.js` if you want to accept email-only leads again.

The form still *collects* a customer's email when they choose to give one — that
lands in the CRM and is useful for sending estimates. It just isn't a channel
anyone can use to reach you unprompted.

### Reviews and testimonials

Two real Google reviews are live on the home and about pages, pulled from your
Business Profile. Both are quoted verbatim with **one** edit: an ellipsis replaces
the profile's former business name ("Phoenix Roofing Contractors", which reviewers
wrote from memory as "Roofing Contractor Phoenix"). No wording was cleaned up and
no claims were added — trimming a name is fine, rewriting a customer's words is not.

Reviewer names are shortened to first name + last initial, which is the usual
convention on a website even though the full names are public on Google. Change
them in `REAL_REVIEWS` if you'd rather show them in full.

To add more, append to `REAL_REVIEWS` in `generate_site.py` and re-run. The layout
adapts automatically (two-up below three reviews, three-up at three or more). If
the list is ever emptied, the testimonials section disappears cleanly rather than
rendering an empty shell.

**There is deliberately no Review or AggregateRating schema on these.** Google
disallows self-serving review markup — a business marking up reviews of itself on
its own website — and using it anyway is a common cause of structured-data manual
actions. The star-rating signal counts on the Google profile, which is where the
reviews actually live and where the "Read all reviews on Google" link points.

The separate credentials section stays regardless. It does a different job than
testimonials: two reviews is thin social proof, and a verifiable ROC number plus a
written-estimate policy carries weight that quotes don't.

### Note on the license number and the address
Arizona requires a licensed contractor's ROC number to appear in advertising, so
**ROC #366348 renders in the header bar and footer of every page** — that's deliberate,
not decorative. It should only stay there for as long as Sun & Shield is actually the
entity performing the work; if that arrangement changes, the number has to come off.

There is **no street address anywhere on the site or in the schema.org markup**.
Sun & Shield doesn't publish one, and a service-area business doesn't need one. Add
`ADDRESS_LINE` and a `streetAddress` in `local_business_schema()` only if there's a
real location customers can visit — Google actively penalizes virtual-office and
fabricated addresses in local results.

## Deploying

The `site` folder is static — no build step, no Node, nothing to compile.

### Website

**Netlify:** drag the `site` folder onto app.netlify.com, or connect a repo and set
the publish directory to `site`. `netlify.toml` is already there and handles clean
URLs, the custom 404, cache headers, and basic security headers.

**Vercel:** import the repo, set the root directory to `site`, framework preset
"Other". `vercel.json` covers the same ground.

**Cloudflare Pages:** connect the repo, build command empty, output directory `site`.

Then point `phoenixroofingcontractors.info` at the host (each provider walks you
through the DNS records) and let them issue the SSL certificate — it's free and
automatic on all three. **Don't launch without HTTPS**; browsers flag plain HTTP
as "Not secure", which is a bad first impression for a contractor asking to get on
someone's roof.

### CRM

Deploy `crm` separately — a different Netlify/Vercel project, framework preset
Vite, build command `npm run build`, output directory `dist`. Add the two env vars
from `crm/.env` (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) in the host's
dashboard.

**Keep the CRM on its own URL and don't link to it from the public site.** It ships
with a `noindex` tag, but the real protection is the login plus the database
policies.

### After the site is live

1. **Add the website URL to your Google Business Profile.** That link is one of the
   higher-value fields on the listing and directly ties it to the site.
2. **Submit the sitemap** in [Google Search Console](https://search.google.com/search-console):
   add the property, verify it (the DNS or HTML-file method), then submit
   `https://www.phoenixroofingcontractors.info/sitemap.xml`. This is how the five
   city pages get discovered quickly instead of waiting to be crawled.
3. **Submit a real test lead** through the form and confirm it shows up on the CRM
   pipeline. End-to-end, on the live domain, once.

## City landing pages

Five city pages live in `site/service-areas/`, targeting "[city] roofing company"
and "[city] roof repair" searches:

| Page | Median home built | The angle |
|---|---|---|
| Gilbert | 2003 | Newest stock; tile underlayment hitting first failure now |
| Chandler | 1997 | Past underlayment life + Price Corridor commercial |
| Mesa | 1989 | Second-cycle replacement; huge range incl. 55+ communities |
| Glendale | 1986 | ~46% built in the 70s/80s; shingle city, storm damage |
| Tempe | 1984 | Oldest + built out; flat/low-slope means foam roofing |

### Why they're built this way

The single biggest risk with city landing pages is Google classifying them as
**doorway pages** — near-identical templates with the city name swapped. That
can suppress the entire set, not just one page. So each page is anchored to a
genuinely different fact: median year of construction, which in Arizona maps
directly onto roof lifecycle, because tile underlayment fails at ~20-25 years
while the tile above it lasts 40-50.

That's not a copywriting trick — it's a real difference in what the customer
needs. A Gilbert homeowner needs a lift-and-relay. A Tempe homeowner with a
1984 flat roof needs foam. Same company, five different conversations.

Measured overlap between the five pages is **under 20%**, including shared
header/footer/form boilerplate. Anything under roughly 55% is comfortably safe.
If you add more cities, re-run the check before publishing — the script is in
the git history, or just ask.

### Data sources

- Median year built: 2024 American Community Survey (US Census) analyzed by NAHB, [reported April 2026](https://www.gilbertsunnews.com/business/valley-houses-still-young-but-aging-fast/article_94a2e1e8-d109-4f93-bb11-ca21e38425ab.html)
- Glendale housing-age breakdown: [Point2Homes Glendale demographics](https://www.point2homes.com/US/Neighborhood/AZ/Glendale-Demographics.html)
- Tile underlayment lifespan and lift-and-relay cost range: [The Arizona Roofer](https://thearizonaroofer.com/tile-roof-underlayment-replacement-arizona/)

**Sanity-check the neighborhood lists before launch.** They're drawn from real
Phoenix-metro communities, but you know these areas better than any source I
can reach — if a name looks off for how locals actually refer to it, fix it in
the `CITIES` dict in `generate_site.py`.

### Adding another city

Add an entry to the `CITIES` dict in `site/generate_site.py` and re-run the
script. Everything else — sitemap, footer links, the linked chips on every
service page, cross-links between city pages — updates automatically. Give the
new city a real, specific angle rather than copying an existing one.

## Quick start

### Website (`/site`)
No build step. Open `site/index.html` in a browser, or serve the folder locally:

```bash
cd site
python3 -m http.server 8000
# visit http://localhost:8000/index.html
```

To regenerate all pages after editing content/copy in `site/generate_site.py`:

```bash
cd site
python3 generate_site.py
```

Deploy `/site` to any static host — Netlify, Vercel, Cloudflare Pages, or plain S3 — by pointing it
at the `site` folder. It's already root-relative (`/css/...`, `/services/...`), so it works as-is
once deployed at a domain root.

### CRM (`/crm`)
A standard Vite + React app.

```bash
cd crm
npm install
npm run dev       # local dev server
npm run build     # production build -> crm/dist
```

Deploy `/crm` to Vercel or Netlify as a standard Vite app (build command `npm run build`, output
directory `dist`). The Supabase URL and key are already set in `crm/.env` — when deploying, copy
those two values into your hosting provider's environment variables (`VITE_SUPABASE_URL`,
`VITE_SUPABASE_ANON_KEY`).

**Keep the CRM URL private** — don't link to it from the public website, and don't index it (it
already ships with a `noindex` meta tag). See Security below for why.

## CRM login (Supabase Auth) — FINISH THIS BEFORE ENTERING REAL CUSTOMERS

The CRM is now behind an email/password login, and the database enforces it:
`anon` can insert a website lead and nothing else. Reading any customer data
requires a logged-in session. Verified by running the queries as the `anon`
role — the lead insert succeeded, contact and deal reads returned zero rows.

**Two things you must do in the Supabase dashboard before this is actually secure.**
The code is done; these are console settings I can't change from here.

### 1. Turn OFF public signups — do this first

[Authentication → Sign In / Providers → Email](https://supabase.com/dashboard/project/bghvhowpwbicojgwwirx/auth/providers)
→ disable **"Allow new users to sign up"**.

This one matters more than anything else on this page. The policies grant access
to any *authenticated* user. If self-signup is left on, anyone who finds the CRM
URL can create their own account, become authenticated, and read every customer
record. Disabling signup means accounts exist only when you create them.

### 2. Create your user account

[Authentication → Users](https://supabase.com/dashboard/project/bghvhowpwbicojgwwirx/auth/users)
→ **Add user** → **Create new user**. Use a real address you can receive mail at,
so password reset works. Repeat for each staff member who needs access.

I deliberately did not create an account or set a password for you — you should
be the only one who has ever known it.

### What the login does

- Session persists across refreshes and restores on load; no login screen flash
- Sign out is in the sidebar, under the signed-in email address
- "Forgot password?" sends a Supabase reset email
- Failed logins return one generic message whether the email exists or not, so
  the form can't be used to discover which addresses have accounts

### Still worth doing later

Current policies are "any authenticated user can do anything." Fine for a small
team where everyone is trusted. If you later want per-user restrictions — a sales
rep who sees only their own deals, say — that needs an `owner_id` column and
policies keyed to `auth.uid()`. Ask when you get there.

## Project structure

```
phoenix-roofing-experts/
├── site/                   # Static SEO website
│   ├── index.html, about.html, contact.html
│   ├── services/            # roof-repair, roof-replacement-installation,
│   │                         # residential-roofing, commercial-roofing, foam-roofing
│   ├── service-areas/       # gilbert, chandler, mesa, tempe, glendale city pages
│   ├── css/style.css
│   ├── js/config.js         # Supabase URL + anon key (public, safe to expose)
│   ├── js/main.js           # wires the contact form to Supabase
│   ├── generate_site.py     # regenerates all HTML pages from templates
│   ├── robots.txt, sitemap.xml
├── crm/                     # React + Vite CRM app
│   ├── src/pages/            # Pipeline.jsx, Contacts.jsx, ContactDetail.jsx, Tasks.jsx
│   ├── src/components/       # modals
│   ├── supabase/migration.sql  # full DB schema, for reference/version control
│   └── .env                  # Supabase URL + anon key
```
