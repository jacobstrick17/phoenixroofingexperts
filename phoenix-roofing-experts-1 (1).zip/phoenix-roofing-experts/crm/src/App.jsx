import React, { useEffect, useState } from "react";
import { Routes, Route, NavLink } from "react-router-dom";
import { supabase } from "./supabaseClient.js";
import Login from "./components/Login.jsx";
import Pipeline from "./pages/Pipeline.jsx";
import Contacts from "./pages/Contacts.jsx";
import ContactDetail from "./pages/ContactDetail.jsx";
import Tasks from "./pages/Tasks.jsx";

export default function App() {
  const [session, setSession] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    // Restore an existing session on load, then follow auth changes.
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChecking(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  // Avoid flashing the login screen while the stored session is being read.
  if (checking) {
    return <div className="boot-screen">Loading…</div>;
  }

  if (!session) {
    return <Login />;
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">🏠</span>
          <div>
            <div className="brand-name">Phoenix Roofing Experts</div>
            <div className="brand-sub">CRM</div>
          </div>
        </div>
        <nav className="side-nav">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
            📋 Pipeline
          </NavLink>
          <NavLink to="/contacts" className={({ isActive }) => (isActive ? "active" : "")}>
            👥 Contacts
          </NavLink>
          <NavLink to="/tasks" className={({ isActive }) => (isActive ? "active" : "")}>
            ✅ Tasks
          </NavLink>
        </nav>
        <div className="sidebar-footer">
          <div className="signed-in-as" title={session.user.email}>
            {session.user.email}
          </div>
          <button className="link-btn" onClick={() => supabase.auth.signOut()}>
            Sign out
          </button>
          <p style={{ marginTop: 12 }}>
            Leads submitted on the website land here automatically as new deals.
          </p>
        </div>
      </aside>
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Pipeline />} />
          <Route path="/contacts" element={<Contacts />} />
          <Route path="/contacts/:id" element={<ContactDetail />} />
          <Route path="/tasks" element={<Tasks />} />
        </Routes>
      </main>
    </div>
  );
}
