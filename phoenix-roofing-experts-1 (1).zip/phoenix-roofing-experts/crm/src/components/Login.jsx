import React, { useState } from "react";
import { supabase } from "../supabaseClient.js";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);

    const { error: err } = await supabase.auth.signInWithPassword({ email, password });

    if (err) {
      // Supabase returns the same message for a bad password and a nonexistent
      // account, on purpose — revealing which one would let someone enumerate
      // valid accounts. Keep it that way.
      setError("That email and password combination didn't work.");
      setBusy(false);
      return;
    }
    // On success the onAuthStateChange listener in App.jsx swaps the view.
  }

  async function handleReset() {
    if (!email) {
      setError("Enter your email address first, then click reset.");
      return;
    }
    setError(null);
    const { error: err } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin,
    });
    setNotice(
      err
        ? "Couldn't send the reset email. Check the address and try again."
        : "If that address has an account, a reset link is on its way."
    );
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-brand">
          <span className="brand-mark">🏠</span>
          <div>
            <div className="brand-name">Phoenix Roofing Experts</div>
            <div className="brand-sub">CRM</div>
          </div>
        </div>

        <h2>Sign in</h2>
        <p className="muted">This dashboard contains customer contact details. Staff access only.</p>

        <form onSubmit={handleSubmit} className="form-stack">
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && <div className="banner error">{error}</div>}
          {notice && <div className="banner notice">{notice}</div>}

          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy ? "Signing in..." : "Sign in"}
          </button>

          <button type="button" className="link-btn" onClick={handleReset}>
            Forgot password?
          </button>
        </form>
      </div>
    </div>
  );
}
