import React, { useState } from "react";
import { supabase } from "../supabaseClient.js";
import Modal from "./Modal.jsx";

export default function NewContactModal({ onClose, onCreated }) {
  const [form, setForm] = useState({ name: "", phone: "", email: "", city: "Phoenix", notes: "" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      if (!form.name) throw new Error("Name is required.");
      const { error: err } = await supabase.from("contacts").insert({ ...form, source: "manual" });
      if (err) throw err;
      onCreated();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal title="New Contact" onClose={onClose}>
      <form onSubmit={handleSubmit} className="form-stack">
        <div className="field">
          <label>Name*</label>
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        </div>
        <div className="field-grid">
          <div className="field">
            <label>Phone</label>
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div className="field">
            <label>Email</label>
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="field">
            <label>City</label>
            <input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          </div>
        </div>
        <div className="field">
          <label>Notes</label>
          <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </div>
        {error && <div className="banner error">{error}</div>}
        <div className="modal-actions">
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Saving..." : "Create Contact"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
