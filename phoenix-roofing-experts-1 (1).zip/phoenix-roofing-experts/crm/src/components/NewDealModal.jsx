import React, { useEffect, useState } from "react";
import { supabase } from "../supabaseClient.js";
import Modal from "./Modal.jsx";

const SERVICE_TYPES = [
  "Roof Repair",
  "Roof Replacement & Installation",
  "Residential Roofing",
  "Commercial Roofing",
  "Spray Foam Roofing",
];

export default function NewDealModal({ stages, onClose, onCreated, defaultContactId }) {
  const [contacts, setContacts] = useState([]);
  const [contactId, setContactId] = useState(defaultContactId || "");
  const [creatingContact, setCreatingContact] = useState(!defaultContactId);
  const [newContact, setNewContact] = useState({ name: "", phone: "", email: "", city: "Phoenix" });
  const [title, setTitle] = useState("");
  const [serviceType, setServiceType] = useState(SERVICE_TYPES[0]);
  const [valueEstimate, setValueEstimate] = useState("");
  const [stageId, setStageId] = useState(stages[0]?.id || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!defaultContactId) {
      supabase
        .from("contacts")
        .select("id, name")
        .order("name")
        .then(({ data }) => setContacts(data || []));
    }
  }, [defaultContactId]);

  useEffect(() => {
    if (stages.length && !stageId) setStageId(stages[0].id);
  }, [stages, stageId]);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      let finalContactId = contactId;

      if (creatingContact) {
        if (!newContact.name) throw new Error("Contact name is required.");
        const { data: c, error: cErr } = await supabase
          .from("contacts")
          .insert({ ...newContact, source: "manual" })
          .select()
          .single();
        if (cErr) throw cErr;
        finalContactId = c.id;
      }

      if (!finalContactId) throw new Error("Select or create a contact.");
      if (!title) throw new Error("Deal title is required.");

      const { data: deal, error: dErr } = await supabase
        .from("deals")
        .insert({
          contact_id: finalContactId,
          title,
          service_type: serviceType,
          value_estimate: valueEstimate ? Number(valueEstimate) : null,
          stage_id: stageId,
        })
        .select()
        .single();
      if (dErr) throw dErr;

      await supabase.from("activities").insert({
        contact_id: finalContactId,
        deal_id: deal.id,
        type: "note",
        body: `Deal created: ${title}`,
      });

      onCreated();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal title="New Deal" onClose={onClose}>
      <form onSubmit={handleSubmit} className="form-stack">
        {!defaultContactId && (
          <>
            <div className="toggle-row">
              <label>
                <input
                  type="radio"
                  checked={!creatingContact}
                  onChange={() => setCreatingContact(false)}
                />
                Existing contact
              </label>
              <label>
                <input type="radio" checked={creatingContact} onChange={() => setCreatingContact(true)} />
                New contact
              </label>
            </div>

            {!creatingContact ? (
              <div className="field">
                <label>Contact</label>
                <select value={contactId} onChange={(e) => setContactId(e.target.value)} required>
                  <option value="">Select a contact...</option>
                  {contacts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="field-grid">
                <div className="field">
                  <label>Name*</label>
                  <input
                    value={newContact.name}
                    onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                    required
                  />
                </div>
                <div className="field">
                  <label>Phone</label>
                  <input
                    value={newContact.phone}
                    onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>Email</label>
                  <input
                    value={newContact.email}
                    onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>City</label>
                  <input
                    value={newContact.city}
                    onChange={(e) => setNewContact({ ...newContact, city: e.target.value })}
                  />
                </div>
              </div>
            )}
          </>
        )}

        <div className="field">
          <label>Deal Title*</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Smith residence re-roof" required />
        </div>

        <div className="field-grid">
          <div className="field">
            <label>Service Type</label>
            <select value={serviceType} onChange={(e) => setServiceType(e.target.value)}>
              {SERVICE_TYPES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Estimated Value ($)</label>
            <input
              type="number"
              value={valueEstimate}
              onChange={(e) => setValueEstimate(e.target.value)}
              placeholder="e.g. 12000"
            />
          </div>
          <div className="field">
            <label>Stage</label>
            <select value={stageId} onChange={(e) => setStageId(Number(e.target.value))}>
              {stages.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {error && <div className="banner error">{error}</div>}

        <div className="modal-actions">
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Saving..." : "Create Deal"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
