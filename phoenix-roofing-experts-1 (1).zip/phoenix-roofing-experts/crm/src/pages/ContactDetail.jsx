import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "../supabaseClient.js";
import NewDealModal from "../components/NewDealModal.jsx";

export default function ContactDetail() {
  const { id } = useParams();
  const [contact, setContact] = useState(null);
  const [deals, setDeals] = useState([]);
  const [stages, setStages] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [note, setNote] = useState("");
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDue, setTaskDue] = useState("");
  const [showNewDeal, setShowNewDeal] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: c, error: cErr }, { data: d }, { data: s }, { data: t }, { data: a }] = await Promise.all([
      supabase.from("contacts").select("*").eq("id", id).single(),
      supabase.from("deals").select("*").eq("contact_id", id).order("created_at", { ascending: false }),
      supabase.from("pipeline_stages").select("*").order("position"),
      supabase.from("tasks").select("*").eq("contact_id", id).order("due_date", { ascending: true }),
      supabase.from("activities").select("*").eq("contact_id", id).order("created_at", { ascending: false }),
    ]);
    if (cErr) setError(cErr.message);
    setContact(c);
    setDeals(d || []);
    setStages(s || []);
    setTasks(t || []);
    setActivities(a || []);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  async function addNote(e) {
    e.preventDefault();
    if (!note.trim()) return;
    await supabase.from("activities").insert({ contact_id: id, type: "note", body: note.trim() });
    setNote("");
    load();
  }

  async function addTask(e) {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    await supabase.from("tasks").insert({ contact_id: id, title: taskTitle.trim(), due_date: taskDue || null });
    setTaskTitle("");
    setTaskDue("");
    load();
  }

  async function toggleTask(task) {
    await supabase.from("tasks").update({ done: !task.done }).eq("id", task.id);
    load();
  }

  if (loading) return <div className="muted">Loading contact...</div>;
  if (error) return <div className="banner error">{error}</div>;
  if (!contact) return <div className="banner error">Contact not found.</div>;

  return (
    <div>
      <Link to="/contacts" className="back-link">
        &larr; All Contacts
      </Link>

      <div className="page-header">
        <div>
          <h1>{contact.name}</h1>
          <p className="muted">
            {contact.phone && <>📞 {contact.phone} &nbsp;</>}
            {contact.email && <>✉️ {contact.email} &nbsp;</>}
            {contact.city && <>📍 {contact.city}</>}
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowNewDeal(true)}>
          + New Deal
        </button>
      </div>

      <div className="detail-grid">
        <div>
          <section className="panel">
            <h3>Deals</h3>
            {deals.length === 0 && <div className="empty-hint">No deals yet.</div>}
            {deals.map((deal) => {
              const stage = stages.find((s) => s.id === deal.stage_id);
              return (
                <div key={deal.id} className="deal-row">
                  <div>
                    <div className="deal-title">{deal.title}</div>
                    <div className="muted">{deal.service_type}</div>
                  </div>
                  <div className="deal-row-right">
                    {deal.value_estimate ? <span>${Number(deal.value_estimate).toLocaleString()}</span> : <span className="muted">No estimate</span>}
                    <span className="badge" style={{ background: stage?.color || "#ccc" }}>
                      {stage?.name || "—"}
                    </span>
                  </div>
                </div>
              );
            })}
          </section>

          <section className="panel">
            <h3>Activity Timeline</h3>
            <form onSubmit={addNote} className="inline-form">
              <input
                placeholder="Log a call, note, or update..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
              <button type="submit" className="btn btn-primary">
                Add Note
              </button>
            </form>
            <div className="timeline">
              {activities.length === 0 && <div className="empty-hint">No activity yet.</div>}
              {activities.map((a) => (
                <div key={a.id} className="timeline-item">
                  <div className="timeline-dot" />
                  <div>
                    <div className="timeline-body">{a.body}</div>
                    <div className="timeline-meta">
                      {a.type} &middot; {new Date(a.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div>
          <section className="panel">
            <h3>Tasks</h3>
            <form onSubmit={addTask} className="form-stack">
              <input placeholder="Task title" value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} />
              <input type="date" value={taskDue} onChange={(e) => setTaskDue(e.target.value)} />
              <button type="submit" className="btn btn-primary">
                Add Task
              </button>
            </form>
            <div className="task-list">
              {tasks.length === 0 && <div className="empty-hint">No tasks yet.</div>}
              {tasks.map((t) => (
                <label key={t.id} className={`task-item ${t.done ? "done" : ""}`}>
                  <input type="checkbox" checked={t.done} onChange={() => toggleTask(t)} />
                  <span>{t.title}</span>
                  {t.due_date && <span className="muted">{new Date(t.due_date).toLocaleDateString()}</span>}
                </label>
              ))}
            </div>
          </section>

          {contact.notes && (
            <section className="panel">
              <h3>Original Inquiry</h3>
              <p>{contact.notes}</p>
            </section>
          )}
        </div>
      </div>

      {showNewDeal && (
        <NewDealModal
          stages={stages}
          defaultContactId={contact.id}
          onClose={() => setShowNewDeal(false)}
          onCreated={() => {
            setShowNewDeal(false);
            load();
          }}
        />
      )}
    </div>
  );
}
