import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../supabaseClient.js";
import NewContactModal from "../components/NewContactModal.jsx";

export default function Contacts() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState("");
  const [showNew, setShowNew] = useState(false);

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase
      .from("contacts")
      .select("*")
      .order("created_at", { ascending: false });
    if (err) setError(err.message);
    setContacts(data || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = contacts.filter((c) => {
    const q = query.toLowerCase();
    return (
      c.name?.toLowerCase().includes(q) ||
      c.email?.toLowerCase().includes(q) ||
      c.phone?.toLowerCase().includes(q) ||
      c.city?.toLowerCase().includes(q)
    );
  });

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Contacts</h1>
          <p className="muted">{contacts.length} total contacts</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowNew(true)}>
          + New Contact
        </button>
      </div>

      <input
        className="search-input"
        placeholder="Search by name, phone, email, or city..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      {error && <div className="banner error">{error}</div>}

      {loading ? (
        <div className="muted">Loading contacts...</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>City</th>
              <th>Source</th>
              <th>Added</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => (
              <tr key={c.id}>
                <td>
                  <Link to={`/contacts/${c.id}`} className="row-link">
                    {c.name}
                  </Link>
                </td>
                <td>{c.phone || "—"}</td>
                <td>{c.email || "—"}</td>
                <td>{c.city || "—"}</td>
                <td>
                  <span className={`badge badge-${c.source === "website" ? "blue" : "gray"}`}>{c.source}</span>
                </td>
                <td>{new Date(c.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="muted">
                  No contacts found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}

      {showNew && (
        <NewContactModal
          onClose={() => setShowNew(false)}
          onCreated={() => {
            setShowNew(false);
            load();
          }}
        />
      )}
    </div>
  );
}
