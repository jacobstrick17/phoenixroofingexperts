import React, { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../supabaseClient.js";
import NewDealModal from "../components/NewDealModal.jsx";

export default function Pipeline() {
  const [stages, setStages] = useState([]);
  const [deals, setDeals] = useState([]);
  const [contactsById, setContactsById] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showNewDeal, setShowNewDeal] = useState(false);
  const [dragDealId, setDragDealId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const [{ data: stageData, error: stageErr }, { data: dealData, error: dealErr }, { data: contactData, error: contactErr }] =
      await Promise.all([
        supabase.from("pipeline_stages").select("*").order("position"),
        supabase.from("deals").select("*").order("created_at", { ascending: false }),
        supabase.from("contacts").select("id, name, phone, email"),
      ]);

    if (stageErr || dealErr || contactErr) {
      setError((stageErr || dealErr || contactErr).message);
      setLoading(false);
      return;
    }

    const cMap = {};
    (contactData || []).forEach((c) => (cMap[c.id] = c));

    setStages(stageData || []);
    setDeals(dealData || []);
    setContactsById(cMap);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function moveDeal(dealId, stageId) {
    setDeals((prev) => prev.map((d) => (d.id === dealId ? { ...d, stage_id: stageId } : d)));
    const { error: updateErr } = await supabase.from("deals").update({ stage_id: stageId }).eq("id", dealId);
    if (updateErr) {
      setError(updateErr.message);
      load();
      return;
    }
    await supabase.from("activities").insert({
      contact_id: deals.find((d) => d.id === dealId)?.contact_id,
      deal_id: dealId,
      type: "status_change",
      body: "Deal moved to a new pipeline stage.",
    });
  }

  const totalPipelineValue = deals
    .filter((d) => {
      const stage = stages.find((s) => s.id === d.stage_id);
      return stage && stage.name !== "Won" && stage.name !== "Lost";
    })
    .reduce((sum, d) => sum + (Number(d.value_estimate) || 0), 0);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Pipeline</h1>
          <p className="muted">
            {deals.length} active deal{deals.length === 1 ? "" : "s"} &middot; Open pipeline value:{" "}
            <strong>${totalPipelineValue.toLocaleString()}</strong>
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowNewDeal(true)}>
          + New Deal
        </button>
      </div>

      {error && <div className="banner error">{error}</div>}
      {loading ? (
        <div className="muted">Loading pipeline...</div>
      ) : (
        <div className="board">
          {stages.map((stage) => {
            const stageDeals = deals.filter((d) => d.stage_id === stage.id);
            return (
              <div
                key={stage.id}
                className="board-column"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  if (dragDealId) moveDeal(dragDealId, stage.id);
                  setDragDealId(null);
                }}
              >
                <div className="board-column-head" style={{ borderTopColor: stage.color }}>
                  <span>{stage.name}</span>
                  <span className="count-pill">{stageDeals.length}</span>
                </div>
                <div className="board-column-body">
                  {stageDeals.map((deal) => {
                    const contact = contactsById[deal.contact_id];
                    return (
                      <div
                        key={deal.id}
                        className="deal-card"
                        draggable
                        onDragStart={() => setDragDealId(deal.id)}
                      >
                        <div className="deal-title">{deal.title}</div>
                        {contact && (
                          <Link to={`/contacts/${contact.id}`} className="deal-contact">
                            {contact.name}
                          </Link>
                        )}
                        {deal.service_type && <div className="deal-service">{deal.service_type}</div>}
                        <div className="deal-meta">
                          {deal.value_estimate ? (
                            <span className="deal-value">${Number(deal.value_estimate).toLocaleString()}</span>
                          ) : (
                            <span className="muted">No estimate yet</span>
                          )}
                          <select
                            value={deal.stage_id}
                            onChange={(e) => moveDeal(deal.id, Number(e.target.value))}
                          >
                            {stages.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    );
                  })}
                  {stageDeals.length === 0 && <div className="empty-hint">No deals here yet.</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showNewDeal && (
        <NewDealModal
          stages={stages}
          onClose={() => setShowNewDeal(false)}
          onCreated={() => {
            setShowNewDeal(false);
            load();
          }}
        />
      )}
    </div>
  );
}
