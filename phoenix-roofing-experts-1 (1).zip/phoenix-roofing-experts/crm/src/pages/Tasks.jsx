import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../supabaseClient.js";

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [contactsById, setContactsById] = useState({});
  const [loading, setLoading] = useState(true);
  const [showDone, setShowDone] = useState(false);

  async function load() {
    setLoading(true);
    const [{ data: t }, { data: c }] = await Promise.all([
      supabase.from("tasks").select("*").order("due_date", { ascending: true }),
      supabase.from("contacts").select("id, name"),
    ]);
    const map = {};
    (c || []).forEach((x) => (map[x.id] = x));
    setTasks(t || []);
    setContactsById(map);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleTask(task) {
    setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, done: !t.done } : t)));
    await supabase.from("tasks").update({ done: !task.done }).eq("id", task.id);
  }

  const visible = tasks.filter((t) => showDone || !t.done);
  const overdue = (t) => t.due_date && !t.done && new Date(t.due_date) < new Date(new Date().toDateString());

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Tasks</h1>
          <p className="muted">{tasks.filter((t) => !t.done).length} open tasks across all contacts</p>
        </div>
        <label className="toggle-inline">
          <input type="checkbox" checked={showDone} onChange={(e) => setShowDone(e.target.checked)} />
          Show completed
        </label>
      </div>

      {loading ? (
        <div className="muted">Loading tasks...</div>
      ) : (
        <div className="task-list task-list-page">
          {visible.length === 0 && <div className="empty-hint">Nothing here — you're all caught up.</div>}
          {visible.map((t) => (
            <div key={t.id} className={`task-item task-item-row ${t.done ? "done" : ""} ${overdue(t) ? "overdue" : ""}`}>
              <label>
                <input type="checkbox" checked={t.done} onChange={() => toggleTask(t)} />
                <span>{t.title}</span>
              </label>
              <div className="task-item-meta">
                {t.contact_id && contactsById[t.contact_id] && (
                  <Link to={`/contacts/${t.contact_id}`}>{contactsById[t.contact_id].name}</Link>
                )}
                {t.due_date && <span className={overdue(t) ? "overdue-text" : "muted"}>{new Date(t.due_date).toLocaleDateString()}</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
