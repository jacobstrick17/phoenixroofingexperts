-- Phoenix Roofing Experts — CRM + lead-capture schema
-- Applied to Supabase project: phoenix-roofing-experts (ref: bghvhowpwbicojgwwirx)
-- This file is kept for reference/version control. It has already been applied;
-- re-running it against the same project will fail on "already exists" errors.
-- If you spin up a fresh Supabase project, run this whole file once to set it up.

create extension if not exists pgcrypto;

-- Pipeline stages (the columns of the deal kanban board)
create table pipeline_stages (
  id serial primary key,
  name text not null,
  position int not null,
  color text not null default '#64748b'
);

insert into pipeline_stages (name, position, color) values
  ('New Lead', 1, '#3b82f6'),
  ('Contacted', 2, '#8b5cf6'),
  ('Estimate Scheduled', 3, '#f59e0b'),
  ('Estimate Sent', 4, '#eab308'),
  ('Negotiation', 5, '#f97316'),
  ('Won', 6, '#22c55e'),
  ('Lost', 7, '#ef4444');

-- Contacts (homeowners / businesses who inquire)
create table contacts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  phone text,
  address text,
  city text default 'Phoenix',
  source text not null default 'website',
  notes text,
  created_at timestamptz not null default now()
);

-- Deals (a potential roofing job tied to a contact, sits in a pipeline stage)
create table deals (
  id uuid primary key default gen_random_uuid(),
  contact_id uuid not null references contacts(id) on delete cascade,
  title text not null,
  service_type text,
  value_estimate numeric,
  stage_id int not null references pipeline_stages(id) default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Tasks (follow-ups, callbacks, estimate visits)
create table tasks (
  id uuid primary key default gen_random_uuid(),
  deal_id uuid references deals(id) on delete cascade,
  contact_id uuid references contacts(id) on delete cascade,
  title text not null,
  due_date date,
  done boolean not null default false,
  created_at timestamptz not null default now()
);

-- Activities (timeline: notes, calls, emails, status changes)
create table activities (
  id uuid primary key default gen_random_uuid(),
  contact_id uuid references contacts(id) on delete cascade,
  deal_id uuid references deals(id) on delete set null,
  type text not null default 'note',
  body text not null,
  created_at timestamptz not null default now()
);

-- Auto-create a "New Lead" deal + activity whenever a website contact comes in
create or replace function handle_new_website_contact()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.source = 'website' then
    insert into deals (contact_id, title, service_type, stage_id)
    values (new.id, new.name || ' - website inquiry', new.notes, 1);

    insert into activities (contact_id, type, body)
    values (new.id, 'note', coalesce('New website lead: ' || new.notes, 'New website lead submitted.'));
  end if;
  return new;
end;
$$;

create trigger on_new_website_contact
  after insert on contacts
  for each row
  execute function handle_new_website_contact();

-- updated_at maintenance on deals
create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger deals_set_updated_at
  before update on deals
  for each row
  execute function set_updated_at();

-- RLS
alter table pipeline_stages enable row level security;
alter table contacts enable row level security;
alter table deals enable row level security;
alter table tasks enable row level security;
alter table activities enable row level security;

-- Public (anon) can INSERT a contact (the website lead form) and read pipeline stage names
create policy "public can submit contact form" on contacts
  for insert to anon
  with check (source = 'website');

-- CRM access requires a logged-in session (Supabase Auth).
--
-- anon can do exactly one thing: insert a website lead, via the
-- "public can submit contact form" policy above. It cannot read, update or
-- delete anything, and cannot touch deals, tasks or activities.
--
-- The handle_new_website_contact trigger is SECURITY DEFINER, so it still
-- creates the New Lead deal and activity rows for an anon submission even
-- though anon has no write access to those tables.
create policy "crm read contacts"   on contacts for select to authenticated using (true);
create policy "crm insert contacts" on contacts for insert to authenticated with check (true);
create policy "crm update contacts" on contacts for update to authenticated using (true) with check (true);
create policy "crm delete contacts" on contacts for delete to authenticated using (true);

create policy "crm manage deals"      on deals      for all to authenticated using (true) with check (true);
create policy "crm manage tasks"      on tasks      for all to authenticated using (true) with check (true);
create policy "crm manage activities" on activities for all to authenticated using (true) with check (true);
create policy "crm read stages"       on pipeline_stages for select to authenticated using (true);
