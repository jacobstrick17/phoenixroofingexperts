#!/usr/bin/env python3
"""Generates the static Phoenix Roofing Experts SEO site from templates.
Run: python3 generate_site.py
"""
import os

ROOT = os.path.dirname(os.path.abspath(__file__))
# ---------------------------------------------------------------------------
# BRAND + CONTACT CONSTANTS
# Edit these, then re-run:  python3 generate_site.py
# ---------------------------------------------------------------------------
SITE_NAME = "Phoenix Roofing Experts"
POWERED_BY = "Sun & Shield Construction and Roofing"

# Arizona ROC license held by Sun & Shield Construction and Roofing.
# Arizona law requires a licensed contractor's number to appear in advertising,
# so this renders in both the site header bar and the footer.
# Source: sunandshieldconstruction.com footer. Verify status/expiration at roc.az.gov.
ROC_LICENSE = "ROC #366348"

# Google Voice business line. Forwards to a mobile; keeps personal numbers private.
# PHONE_DISPLAY is what visitors read; PHONE_TEL is the tel: link they tap on
# mobile — always update the two together.
PHONE_DISPLAY = "(480) 331-1017"
PHONE_TEL = "+14803311017"

# No public email address by choice: leads come in by phone or the form only.
# Set this to a real address to bring the mailto: links back everywhere at once.
EMAIL = None
# Live domain. Note it reads "contractors" while the brand reads "Experts" — the
# domain is the weakest of the three name signals, so brand stays matched to the
# Google Business Profile instead. See README.
DOMAIN = "https://www.phoenixroofingcontractors.info"

# Sun & Shield does not publish a street address, and a service-area business
# doesn't need one. No street address is invented anywhere on the site or in
# the schema.org markup — add one here only if you open a storefront customers
# can actually visit (Google penalizes fake/virtual-office addresses).
ADDRESS_LINE = "Serving the Greater Phoenix Metro Area"

# Google Business Profile for Phoenix Roofing Experts. Published in schema.org
# "sameAs" so search engines tie this site to that listing as one entity.
# NOTE: this is a share.google short link, which works but is a redirect. Prefer
# the canonical profile URL when you have it — open the profile in Google Maps
# and copy the address bar (it looks like https://www.google.com/maps/place/...
# or https://maps.google.com/?cid=<number>).
GOOGLE_BUSINESS_PROFILE = "https://share.google/XgQeBU3YkIgXIq8ny"

import html as _html


def esc(text, quote=False):
    """Normalize then escape text for safe embedding in HTML.

    Unescapes first so that content authored either way — a literal "&" or a
    pre-written "&amp;" — lands in exactly one canonical form and can never be
    double-escaped into "&amp;amp;".
    """
    return _html.escape(_html.unescape(str(text)), quote=quote)


def plain(text):
    """Entity-free text for JSON-LD, which is JSON and not HTML.

    Structured data must carry real characters; a literal "&amp;" or "&mdash;"
    in a schema field is read by search engines as those characters, not as
    "&" or an em dash.
    """
    return _html.unescape(str(text))


# HTML-safe version of the partner name (the "&" must be &amp; in markup).
# Use POWERED_BY for JSON-LD / plain text, POWERED_BY_HTML inside markup.
POWERED_BY_HTML = esc(POWERED_BY)

SERVICE_AREAS = ["Phoenix", "Scottsdale", "Tempe", "Mesa", "Chandler", "Gilbert",
                  "Glendale", "Peoria", "Surprise", "Ahwatukee"]

NAV_LINKS = [
    ("/index.html", "Home"),
    ("/services/roof-repair.html", "Roof Repair"),
    ("/services/roof-replacement-installation.html", "Roof Replacement"),
    ("/services/residential-roofing.html", "Residential"),
    ("/services/commercial-roofing.html", "Commercial"),
    ("/services/foam-roofing.html", "Foam Roofing"),
    ("/about.html", "About"),
    ("/contact.html", "Contact"),
]

SERVICE_LINKS = [
    ("/services/roof-repair.html", "Roof Repair"),
    ("/services/roof-replacement-installation.html", "Roof Replacement & Installation"),
    ("/services/residential-roofing.html", "Residential Roofing"),
    ("/services/commercial-roofing.html", "Commercial Roofing"),
    ("/services/foam-roofing.html", "Spray Foam Roofing"),
]


def nav_html(current_path):
    items = []
    for href, label in NAV_LINKS:
        cls = ' class="active"' if href == current_path else ''
        items.append(f'<li><a href="{href}"{cls}>{label}</a></li>')
    return "\n          ".join(items)


def header_html(current_path):
    return f"""
<div class="top-bar">
  <div class="container">
    <div>Serving the Greater Phoenix Metro &mdash; Licensed &amp; Fully Insured &middot; {ROC_LICENSE}</div>
    <div><a href="tel:{PHONE_TEL}" class="top-phone">📞 {PHONE_DISPLAY}</a> &nbsp;|&nbsp; <a href="/contact.html">Get a Free Estimate</a></div>
  </div>
</div>
<header class="site-header">
  <div class="container nav-wrap" style="position:relative;">
    <a href="/index.html" class="logo">🏠 {SITE_NAME.split(' ')[0]} <span>{ ' '.join(SITE_NAME.split(' ')[1:]) }</span></a>
    <nav class="primary-nav">
      <ul>
          {nav_html(current_path)}
      </ul>
    </nav>
    <div class="nav-cta">
      <a href="tel:{PHONE_TEL}" class="btn btn-navy"><span class="btn-text">Call Now: </span>{PHONE_DISPLAY}</a>
      <button class="menu-toggle" aria-label="Toggle menu">☰</button>
    </div>
  </div>
</header>
"""


def footer_html():
    email_line = f'<br>✉️ <a href="mailto:{EMAIL}">{EMAIL}</a>' if EMAIL else ""
    service_items = "\n            ".join(f'<li><a href="{href}">{label}</a></li>' for href, label in SERVICE_LINKS)
    # Cities with a dedicated landing page get linked; the rest stay plain text.
    _city_page_by_name = {CITIES[s]["name"]: city_path(s) for s in CITIES}
    area_items = "\n            ".join(
        (f'<li><a href="{_city_page_by_name[a]}">{a}, AZ</a></li>'
         if a in _city_page_by_name else f'<li>{a}, AZ</li>')
        for a in SERVICE_AREAS
    )
    year = "2026"
    return f"""
<footer class="site-footer">
  <div class="container">
    <div class="grid">
      <div>
        <h4>{SITE_NAME}</h4>
        <p>Roofing services for the Greater Phoenix metro area &mdash; residential, commercial, and spray foam roofing.</p>
        <p style="color:#8fa0b3;">Powered by <strong style="color:#cfd8e3;">{POWERED_BY_HTML}</strong><br>Arizona {ROC_LICENSE} &middot; Licensed &amp; Fully Insured</p>
        <p>📍 {ADDRESS_LINE}<br>📞 <a href="tel:{PHONE_TEL}">{PHONE_DISPLAY}</a>{email_line}</p>
      </div>
      <div>
        <h4>Services</h4>
        <ul>
            {service_items}
        </ul>
      </div>
      <div>
        <h4>Company</h4>
        <ul>
          <li><a href="/about.html">About Us</a></li>
          <li><a href="/contact.html">Contact</a></li>
          <li><a href="/contact.html">Free Estimate</a></li>
        </ul>
      </div>
      <div>
        <h4>Service Areas</h4>
        <ul>
            {area_items}
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div>&copy; {year} {SITE_NAME}. All rights reserved.</div>
      <div>Work performed by {POWERED_BY_HTML} &middot; Arizona {ROC_LICENSE}</div>
    </div>
  </div>
</footer>
<script src="/js/config.js"></script>
<script src="/js/main.js"></script>
"""


def page(current_path, title, meta_description, canonical, breadcrumb, body_html, schema_json="", robots="index, follow"):
    # schema_json may be a single JSON string or a list of them (city pages emit
    # both a LocalBusiness block and an FAQPage block).
    if isinstance(schema_json, (list, tuple)):
        schema_block = "\n".join(
            f'<script type="application/ld+json">\n{s}\n</script>' for s in schema_json if s
        )
    else:
        schema_block = f'<script type="application/ld+json">\n{schema_json}\n</script>' if schema_json else ""
    title = esc(title, quote=True)
    meta_description = esc(meta_description, quote=True)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="{meta_description}">
<link rel="canonical" href="{DOMAIN}{canonical}">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{meta_description}">
<meta property="og:type" content="website">
<meta property="og:url" content="{DOMAIN}{canonical}">
<meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:image" content="{DOMAIN}/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="{DOMAIN}/og-image.png">
<meta name="theme-color" content="#0f2438">
<meta name="robots" content="{robots}">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="stylesheet" href="/css/style.css">
{schema_block}
</head>
<body>
{header_html(current_path)}
{body_html}
{footer_html()}
</body>
</html>
"""


def write(path, content):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w") as f:
        f.write(content)
    print("wrote", path)


def lead_form(heading="Get Your Free Roofing Estimate", button_text="Get My Free Estimate", compact=False):
    services_options = "\n            ".join(
        f'<option value="{label}">{label}</option>' for _, label in SERVICE_LINKS
    )
    card_class = "hero-card" if not compact else "contact-form"
    return f"""
<div class="{card_class}">
  <h3>{heading}</h3>
  <p style="font-size:0.9rem;color:#495057;">No obligation. We typically respond within one business hour.</p>
  <form data-lead-form>
    <div class="form-grid">
      <div class="form-field full">
        <label for="name">Full Name*</label>
        <input type="text" id="name" name="name" required>
      </div>
      <div class="form-field">
        <label for="phone">Phone*</label>
        <input type="tel" id="phone" name="phone" required>
      </div>
      <div class="form-field">
        <label for="email">Email <span style="font-weight:400;color:#6b7684;">(optional)</span></label>
        <input type="email" id="email" name="email">
      </div>
      <div class="form-field">
        <label for="city">City</label>
        <input type="text" id="city" name="city" placeholder="e.g. Scottsdale" value="Phoenix">
      </div>
      <div class="form-field">
        <label for="service">Service Needed</label>
        <select id="service" name="service">
          <option value="">Select a service</option>
          {services_options}
        </select>
      </div>
      <div class="form-field full">
        <label for="message">Tell us about your roof</label>
        <textarea id="message" name="message" placeholder="Leak, storm damage, new build, re-roof, etc."></textarea>
      </div>
    </div>
    <div style="margin-top:16px;">
      <button type="submit" class="btn" data-default-text="{button_text}">{button_text}</button>
    </div>
    <div data-form-status id="form-status"></div>
    <p class="form-note">By submitting, you agree to be contacted by {SITE_NAME} about your roofing project.</p>
  </form>
</div>
"""


# ---------------------------------------------------------------------------
# SOCIAL PROOF
#
# REAL_REVIEWS is empty on purpose. While it is empty the site renders a
# credentials section built entirely from verifiable facts. Add verified
# reviews to the list and every page automatically switches to testimonials
# instead — no other change needed.
#
# Only put a review here if it (a) names THIS business or Sun & Shield, and
# (b) came from an actual customer. A review naming some other company cannot
# be reused here: the FTC's rule on fake and misleading reviews treats
# misappropriating another business's reviews as a civil-penalty violation,
# and review schema on fabricated reviews is a standing target for Google
# manual actions.
# ---------------------------------------------------------------------------

REAL_REVIEWS = [
    # Verbatim from the Google Business Profile, with one edit: the ellipsis
    # replaces the profile's former business name ("Phoenix Roofing Contractors",
    # which reviewers wrote from memory as "Roofing Contractor Phoenix"). Nothing
    # else is altered — no wording cleaned up, no claims added.
    {
        "name": "Victor O.",
        "location": "Seville, Gilbert, AZ",
        "service": "Roof installation",
        "date": "19 weeks ago",
        "quote": ("The team \u2026 handled our roof installation in Seville with professionalism, "
                   "communication, and patience. They walked us through every detail, answered "
                   "questions, and executed perfect craftsmanship. The roof looks amazing and "
                   "stands strong."),
    },
    {
        "name": "Yosef G.",
        "location": "Queen Creek, AZ",
        "service": "Commercial roof coating",
        "date": "14 weeks ago",
        "quote": ("Our commercial property near Queen Creek Marketplace corridor needed roof "
                   "coating for longevity \u2026 They coordinated around business hours and left "
                   "us with zero mess behind. Customers and staff both noticed how much better "
                   "the building looks now."),
    },
]


def testimonials_block():
    """Real Google reviews. Renders nothing at all when REAL_REVIEWS is empty.

    Deliberately NO Review/AggregateRating schema here: Google disallows
    self-serving review markup (a business marking up reviews of itself on its
    own site), and using it anyway risks a structured-data manual action.
    The reviews live on the Google profile, which is where the rating signal
    actually counts.
    """
    if not REAL_REVIEWS:
        return ""

    grid = "grid-3" if len(REAL_REVIEWS) >= 3 else "grid-2"
    cards = "".join(f"""
        <div class="testimonial">
          <div class="stars">★★★★★</div>
          <p class="quote">"{esc(r['quote'])}"</p>
          <div class="name">{esc(r['name'])}</div>
          <div class="role">{esc(r['service'])} &middot; {esc(r['location'])} &middot; {esc(r['date'])}</div>
        </div>""" for r in REAL_REVIEWS)

    return f"""
<section class="alt">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Reviews</span>
      <h2>What Our Customers Say</h2>
      <p>Verified reviews from our Google Business Profile.</p>
    </div>
    <div class="grid {grid}" style="max-width:900px;margin:0 auto;">
      {cards}
    </div>
    <p style="text-align:center;margin-top:28px;">
      <a href="{GOOGLE_BUSINESS_PROFILE}" rel="nofollow noopener" target="_blank">Read all reviews on Google &rarr;</a>
    </p>
  </div>
</section>
"""


def credentials_block():
    """Verifiable credentials. Always renders — it does a different job than
    testimonials do, so both appear once real reviews exist."""
    items = [
        ("🪪", "A license you can actually check",
         f"Roofing work is performed by {POWERED_BY} under Arizona {ROC_LICENSE}. "
         f"You can look that number up yourself at roc.az.gov before you let anyone on your roof — "
         f"and you should, with any contractor you call."),
        ("📋", "A written, itemized estimate",
         "You get the scope, the materials, and the price in writing before work starts. "
         "If we find damaged decking once the roof is open, you hear about it and approve it "
         "before we proceed — no surprise line items at the end."),
        ("🔍", "A free inspection that ends in a straight answer",
         "We photograph the roof, check the decking, flashing, and ventilation, and tell you "
         "what we actually find — including when the honest answer is that your roof has "
         "several years left and you don't need us yet."),
        ("🛡️", "Licensed and fully insured on every job",
         "Liability coverage is in place before a crew sets foot on your property. "
         "Ask any roofer for proof of both license and insurance; a legitimate one will hand it over."),
    ]
    cards = "".join(f"""
        <div class="card">
          <div class="icon">{icon}</div>
          <h3>{title}</h3>
          <p>{body}</p>
        </div>""" for icon, title, body in items)

    return f"""
<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Why Trust Us</span>
      <h2>We'd Rather Show You Credentials Than Slogans</h2>
      <p>Every claim on this page is something you can verify before you hire anyone.</p>
    </div>
    <div class="grid grid-2">
      {cards}
    </div>
  </div>
</section>
"""


def service_area_block():
    # Cities with their own landing page render as links so internal link equity
    # flows to them from every service page and the home page.
    city_page_by_name = {CITIES[s]["name"]: city_path(s) for s in CITIES}
    chips = "\n      ".join(
        (f'<a class="chip chip-link" href="{city_page_by_name[a]}">{a}, AZ &rarr;</a>'
         if a in city_page_by_name else f'<span class="chip">{a}, AZ</span>')
        for a in SERVICE_AREAS
    )
    return f"""
<section id="service-areas">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Service Area</span>
      <h2>Proudly Serving the Greater Phoenix Metro</h2>
      <p>Local roofing crews and fast response times across the Valley. Highlighted cities have their own page with details on that area's housing and roof types.</p>
    </div>
    <div class="chip-row" style="justify-content:center;">
      {chips}
    </div>
  </div>
</section>
"""


def cta_band(heading="Ready to Fix, Replace, or Upgrade Your Roof?", sub="Get a free, no-pressure roof inspection and written estimate from a local Phoenix roofing crew."):
    return f"""
<section class="cta-band">
  <div class="container">
    <h2>{heading}</h2>
    <p>{sub}</p>
    <a href="tel:{PHONE_TEL}" class="btn btn-outline">Call {PHONE_DISPLAY}</a>
    &nbsp;
    <a href="/contact.html" class="btn" style="background:var(--navy);">Request Free Estimate</a>
  </div>
</section>
"""


def faq_block(title, faqs):
    items = "\n      ".join(
        f'<div class="faq-item"><h4>{esc(q)}</h4><p>{esc(a)}</p></div>' for q, a in faqs
    )
    return f"""
<section class="alt">
  <div class="container" style="max-width:820px;">
    <div class="section-head">
      <span class="eyebrow">FAQ</span>
      <h2>{title}</h2>
    </div>
    {items}
  </div>
</section>
"""


def faq_schema(faqs, canonical):
    import json
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": plain(q),
                "acceptedAnswer": {"@type": "Answer", "text": plain(a)}
            } for q, a in faqs
        ]
    }, indent=2)


def local_business_schema():
    import json
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "RoofingContractor",
        "name": SITE_NAME,
        "image": f"{DOMAIN}/images/logo.png",
        "url": DOMAIN,
        "telephone": PHONE_TEL,
        "priceRange": "$$",
        # Service-area business: no storefront, so no streetAddress is published.
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "Phoenix",
            "addressRegion": "AZ",
            "addressCountry": "US"
        },
        "areaServed": [{"@type": "City", "name": a} for a in SERVICE_AREAS],
        "sameAs": [GOOGLE_BUSINESS_PROFILE] if GOOGLE_BUSINESS_PROFILE else []
    }, indent=2)


SERVICES = {
    "roof-repair": {
        "nav": "/services/roof-repair.html",
        "title": "Roof Repair Phoenix AZ | Emergency Leak & Storm Repair",
        "meta": "Fast roof repair in Phoenix, AZ. Same-day emergency leak repair, monsoon storm damage, and tile or shingle repair. Free written estimates.",
        "eyebrow": "Roof Repair",
        "h1": "Phoenix Roof Repair That Stops Leaks Fast",
        "lead": "From monsoon storm damage to slow leaks that show up as stains on your ceiling, our licensed roof repair crews respond fast across the Phoenix metro.",
        "intro": [
            "Arizona roofs take a beating that most parts of the country never see: intense UV exposure that dries out shingles and underlayment, summer heat cycling that cracks tile and cement, and monsoon-season wind, dust (haboobs), and downpours that find every weak point in a roofing system. A small issue ignored through one more monsoon season often turns into a full interior repair.",
            "Phoenix Roofing Experts provides prompt, honest roof repair for homeowners and businesses across the Valley. We diagnose the actual source of a leak — not just the spot where water is showing up inside — and repair it correctly the first time.",
        ],
        "bullets": [
            "Emergency roof leak repair, including same-day and after-storm response",
            "Monsoon and wind storm damage repair",
            "Tile roof repair — cracked, slipped, or missing tiles",
            "Asphalt shingle repair and patching",
            "Flashing, vent boot, and flat-roof leak repair",
            "Roof leak detection and moisture inspections",
        ],
        "faqs": [
            ("How much does roof repair cost in Phoenix?", "Most minor to moderate roof repairs in the Phoenix area range from a few hundred dollars for a spot leak repair up to several thousand for extensive storm or tile damage. We provide a written, itemized estimate before any work begins."),
            ("How fast can you respond to an emergency roof leak?", "We prioritize active leaks and storm damage calls and can typically get a crew out same-day or next-day, depending on your location in the Valley and current demand after major storms."),
            ("Do you repair tile roofs, or only shingle roofs?", "Both. Tile is one of the most common roofing materials on Phoenix-area homes, and our crews are experienced with concrete tile, clay tile, and asphalt shingle repair."),
            ("Will homeowners insurance cover my roof repair?", "Many storm and wind damage repairs are covered by homeowners insurance. We can document the damage with photos and a written estimate to support your claim, though coverage always depends on your specific policy."),
        ],
    },
    "roof-replacement-installation": {
        "nav": "/services/roof-replacement-installation.html",
        "title": "Roof Replacement Phoenix AZ | New Roof Installation",
        "meta": "Full roof replacement and new roof installation in Phoenix, AZ. Tile, shingle, metal and flat roofing. Licensed, insured, free estimates.",
        "eyebrow": "Roof Replacement & Installation",
        "h1": "Roof Replacement & New Roof Installation in Phoenix",
        "lead": "When repairs no longer make sense, our crews handle complete tear-offs and new roof installations for homes, new construction, and commercial buildings across the Valley.",
        "intro": [
            "Between intense summer heat and UV exposure, most roofing materials in the Phoenix area have a shorter effective lifespan than in milder climates — typically 15-25 years depending on material and installation quality. If your roof is aging, showing widespread wear, or was damaged badly enough that repeated repairs aren't cost-effective, a full replacement protects your home or building and can meaningfully lower cooling costs.",
            "We handle the entire process: tear-off and haul-away of the old roofing system, deck inspection and repair, underlayment and flashing, and installation of your new roofing material — backed by manufacturer and workmanship warranties.",
        ],
        "bullets": [
            "Complete tear-off and re-roof for homes and businesses",
            "New construction roof installation",
            "Tile roof replacement (concrete and clay)",
            "Asphalt shingle roof replacement",
            "Flat and low-slope roof replacement",
            "Manufacturer and workmanship warranty options",
        ],
        "faqs": [
            ("How much does a new roof cost in Phoenix?", "Cost depends heavily on roof size, pitch, and material — asphalt shingle is typically the most affordable, while tile, metal, and foam/flat systems cost more upfront but can last longer or reduce energy costs. We provide a free, itemized estimate for your specific roof."),
            ("How long does a full roof replacement take?", "A typical residential replacement takes one to three days once materials are on site; larger commercial roofs and tile installations can take longer. We'll give you a specific timeline as part of your estimate."),
            ("What's the best roofing material for Phoenix heat?", "There's no single best answer — concrete tile and foam/coated flat roofs both perform very well in extreme heat, while quality shingle products with proper attic ventilation remain a cost-effective option. We'll walk you through the trade-offs for your home."),
            ("Can you help with an insurance claim for a full roof replacement?", "Yes. If your roof was damaged by hail, wind, or storms, we can provide photo documentation and a detailed estimate to support your claim with your insurance carrier."),
        ],
    },
    "residential-roofing": {
        "nav": "/services/residential-roofing.html",
        "title": "Residential Roofing Phoenix AZ | Tile & Shingle Roofers",
        "meta": "Residential roofing company serving Phoenix, Scottsdale, Mesa, Tempe and Chandler. Shingle, tile and metal roofing. Free estimates.",
        "eyebrow": "Residential Roofing",
        "h1": "Residential Roofing Services for Phoenix-Area Homeowners",
        "lead": "As a residential roofing company built for the Valley's climate and HOA communities, we help homeowners repair, maintain, and replace roofs with materials suited to Arizona heat.",
        "intro": [
            "Your roof is one of the biggest investments in your home, and in the Phoenix area it also plays a direct role in your energy bills. We work with homeowners throughout Phoenix, Scottsdale, Tempe, Mesa, Chandler, Gilbert, Glendale, and surrounding communities on everything from single-leak repairs to full re-roofs, including HOA-compliant tile and color matching.",
            "Every residential job starts with a thorough roof inspection and a clear, written estimate — no pressure, no surprise charges.",
        ],
        "bullets": [
            "Asphalt shingle roofing — repair, replacement, and installation",
            "Concrete and clay tile roofing, including HOA color/style matching",
            "Metal roofing for homes",
            "Reflective roof coatings to reduce attic heat",
            "Attic ventilation and insulation assessment",
            "Gutter inspection and roof-to-gutter drainage fixes",
        ],
        "faqs": [
            ("Do you work with HOA roofing requirements?", "Yes, we regularly match tile profiles and colors to satisfy HOA architectural guidelines in Phoenix-area communities."),
            ("How often should a residential roof be inspected in Arizona?", "We generally recommend an inspection once a year and again after any significant monsoon storm, since UV and heat damage can be gradual and easy to miss from the ground."),
            ("Can a new roof lower my cooling bill?", "Reflective tile, coated roofs, and proper attic ventilation can noticeably reduce heat transfer into your attic, which is one of the biggest drivers of summer cooling costs in Phoenix homes."),
            ("Do you offer financing for residential roof replacement?", "We can discuss financing and insurance-claim options during your free estimate so you understand all the ways to fund the project before work begins."),
        ],
    },
    "commercial-roofing": {
        "nav": "/services/commercial-roofing.html",
        "title": "Commercial Roofing Phoenix AZ | TPO & Flat Roof Repair",
        "meta": "Commercial roofing contractor for Phoenix-area businesses. TPO, EPDM, flat roof repair, replacement and maintenance programs.",
        "eyebrow": "Commercial Roofing",
        "h1": "Commercial Roofing Services for Phoenix & Valley Businesses",
        "lead": "We help property managers, business owners, and facilities teams protect flat and low-slope commercial roofs with minimal disruption to tenants and operations.",
        "intro": [
            "Commercial roofs in the Phoenix area face constant thermal cycling and intense UV exposure, which accelerates membrane aging on TPO, EPDM, and built-up roofing systems. Left unmanaged, small membrane failures turn into interior water damage, tenant complaints, and costly emergency calls.",
            "We work with property managers and business owners on both one-time repair or replacement projects and ongoing preventive maintenance programs, scheduled around your operating hours whenever possible.",
        ],
        "bullets": [
            "TPO roof installation and repair",
            "EPDM (rubber) roofing systems",
            "Built-up and modified bitumen roofing",
            "Commercial roof replacement and re-roofing",
            "Preventive maintenance and inspection programs",
            "Tenant-safe, scheduled service for multi-unit and occupied buildings",
        ],
        "faqs": [
            ("What types of commercial roofs do you service?", "We work on TPO, EPDM, built-up/modified bitumen, and coated flat roofs on retail, office, industrial, and multi-family properties throughout the Phoenix metro."),
            ("Do you offer maintenance contracts for commercial properties?", "Yes, we offer scheduled inspection and maintenance programs designed to catch membrane wear, ponding water, and flashing issues before they become leaks."),
            ("Can you work around our business hours?", "In most cases, yes. We coordinate scheduling with property managers and tenants to minimize disruption, including after-hours or weekend work when needed."),
            ("How long does a commercial roof replacement take?", "Timeline depends on roof size and system type; we provide a specific project schedule as part of your estimate, along with options to phase work on larger properties."),
        ],
    },
    "foam-roofing": {
        "nav": "/services/foam-roofing.html",
        "title": "Spray Foam Roofing Phoenix AZ | SPF Flat Roof Experts",
        "meta": "Spray polyurethane foam (SPF) roofing in Phoenix, AZ. Seamless, energy-efficient foam roofs and recoating for low-slope roofs.",
        "eyebrow": "Spray Foam Roofing",
        "h1": "Spray Polyurethane Foam (SPF) Roofing in Phoenix",
        "lead": "Foam roofing is one of the most popular flat-roof systems in Arizona for a reason: it's seamless, adds insulation value, and reflects the desert sun instead of absorbing it.",
        "intro": [
            "Spray polyurethane foam (SPF) roofing is sprayed directly onto a flat or low-slope roof, where it expands and cures into a fully seamless, monolithic surface with no seams for water to find. Topped with a reflective elastomeric coating, foam roofing reduces rooftop surface temperatures significantly compared to a dark built-up or shingle roof — which is a major reason it's so common on Phoenix-area homes and commercial buildings.",
            "Foam roofing is also one of the few systems that can typically be maintained and recoated over its life rather than fully torn off and replaced, which keeps long-term costs down.",
        ],
        "bullets": [
            "New SPF foam roof application for flat and low-slope roofs",
            "Foam roof recoating and maintenance to extend roof life",
            "Reflective, energy-efficient roof coatings",
            "Foam roof insulation for better attic and interior temperatures",
            "Residential and commercial applications",
            "Roof leak repair on existing foam roofs",
        ],
        "faqs": [
            ("How long does foam roofing last?", "A well-maintained SPF roof can last 20+ years, since the foam itself typically isn't replaced — it's recoated every several years to protect it from UV exposure, which is far less disruptive and costly than a full tear-off."),
            ("Is foam roofing actually good for Arizona heat?", "Yes — this is one of the main reasons it's popular here. The foam adds insulation value, and a reflective topcoat significantly reduces how much heat the roof absorbs and transfers into the building below."),
            ("How does the cost compare to a traditional flat roof?", "Initial installation cost is comparable to or somewhat higher than other flat-roof systems, but the ability to recoat instead of replace generally lowers total cost of ownership over 15-20+ years."),
            ("Can foam roofing be applied over an existing flat roof?", "In many cases, yes — foam can be applied over an existing built-up or modified bitumen roof if the deck and substrate are in acceptable condition, which we verify during inspection."),
        ],
    },
}


def build_service_page(slug):
    s = SERVICES[slug]
    canonical = s["nav"]
    bullets_html = "\n      ".join(f"<li>{b}</li>" for b in s["bullets"])
    intro_html = "\n      ".join(f"<p>{p}</p>" for p in s["intro"])
    other_services = [v for k, v in SERVICES.items() if k != slug]
    other_cards = "\n      ".join(
        f'''<div class="card">
          <h3><a href="{o['nav']}">{o['eyebrow']}</a></h3>
          <p>{o['lead']}</p>
          <a href="{o['nav']}">Learn more &rarr;</a>
        </div>''' for o in other_services[:3]
    )

    body = f"""
<div class="page-hero">
  <div class="container">
    <div class="breadcrumbs"><a href="/index.html">Home</a> / <a href="/index.html#services">Services</a> / {s['eyebrow']}</div>
    <span class="eyebrow" style="color:#ff9a56;">{s['eyebrow']}</span>
    <h1>{s['h1']}</h1>
    <p class="lead" style="max-width:640px;">{s['lead']}</p>
  </div>
</div>

<section>
  <div class="container two-col">
    <div>
      {intro_html}
      <ul class="service-list">
      {bullets_html}
      </ul>
      <a href="/contact.html" class="btn">Request a Free Estimate</a>
    </div>
    <div>
      {lead_form(heading="Get a Free " + s['eyebrow'] + " Estimate")}
    </div>
  </div>
</section>

{service_area_block()}
{faq_block(s['eyebrow'] + " FAQs", s['faqs'])}

<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Related Services</span>
      <h2>Other Ways We Can Help</h2>
    </div>
    <div class="grid grid-3">
      {other_cards}
    </div>
  </div>
</section>

{cta_band()}
"""
    schema = faq_schema(s["faqs"], canonical)
    html = page(
        current_path=s["nav"],
        title=s["title"],
        meta_description=s["meta"],
        canonical=canonical,
        breadcrumb=s["eyebrow"],
        body_html=body,
        schema_json=schema,
    )
    write(s["nav"].lstrip("/"), html)


def build_home():
    service_cards = "\n      ".join(
        f'''<div class="card">
          <div class="icon">{icon}</div>
          <h3><a href="{s['nav']}">{s['eyebrow']}</a></h3>
          <p>{s['lead']}</p>
          <a href="{s['nav']}">Learn more &rarr;</a>
        </div>''' for icon, (k, s) in zip(["🔧", "🏗️", "🏡", "🏢", "💧"], SERVICES.items())
    )

    body = f"""
<section class="hero">
  <div class="container">
    <div>
      <span class="eyebrow" style="color:#ff9a56;">Phoenix, AZ Roofing Contractor</span>
      <h1>Phoenix's Trusted Roof Repair, Replacement &amp; Foam Roofing Experts</h1>
      <p class="lead">Licensed and fully insured roofing contractor serving homeowners and businesses across the Valley — roof repair, full replacement, residential, commercial, and spray foam roofing.</p>
      <div class="hero-cta-row">
        <a href="tel:{PHONE_TEL}" class="btn btn-outline">Call {PHONE_DISPLAY}</a>
        <a href="#lead-form" class="btn">Get a Free Estimate</a>
      </div>
      <div class="hero-badges">
        <div>✅ Licensed &amp; Insured</div>
        <div>⚡ Same-Day Emergency Response</div>
        <div>📍 Locally Owned in Phoenix, AZ</div>
      </div>
    </div>
    <div id="lead-form">
      {lead_form()}
    </div>
  </div>
</section>

<div class="stat-strip">
  <div class="container grid">
    <div><div class="num">15+</div><div class="label">Years Serving the Valley</div></div>
    <div><div class="num">100%</div><div class="label">Licensed &amp; Fully Insured</div></div>
    <div><div class="num">24/7</div><div class="label">Storm Damage Response</div></div>
    <div><div class="num">10</div><div class="label">Phoenix-Metro Cities Served</div></div>
  </div>
</div>

<section id="services">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">What We Do</span>
      <h2>Roofing Services for Every Property in the Valley</h2>
      <p>From a single storm-damaged tile to a full commercial re-roof, our crews handle it with a written estimate up front.</p>
    </div>
    <div class="grid grid-3">
      {service_cards}
    </div>
  </div>
</section>

<section class="alt">
  <div class="container two-col">
    <div>
      <span class="eyebrow">Why Phoenix Roofing Experts</span>
      <h2>Built for Arizona Roofs, Not Generic Ones</h2>
      <p>Roofing in the desert isn't the same as roofing anywhere else. Monsoon wind and hail, extreme UV exposure, and summer heat cycling all shorten the life of a roof faster than milder climates — and they change which materials and techniques actually hold up.</p>
      <ul class="service-list">
        <li>Local crews who know Valley HOA and building code requirements</li>
        <li>Upfront, written estimates — no surprise charges</li>
        <li>Manufacturer and workmanship warranties on replacements</li>
        <li>Insurance claim documentation support for storm damage</li>
      </ul>
      <a href="/about.html" class="btn btn-navy">More About Us</a>
    </div>
    <div class="card" style="padding:36px;">
      <h3>Not Sure What You Need?</h3>
      <p>If you're seeing a stain on your ceiling, missing tiles after a storm, or just want to know how much life is left in your roof, start with a free inspection. We'll walk you through exactly what we find and what your options are — repair, replacement, or foam recoat — with real numbers, not pressure tactics.</p>
      <a href="/contact.html" class="btn">Schedule a Free Inspection</a>
    </div>
  </div>
</section>

{testimonials_block()}\n{credentials_block()}
{service_area_block()}

{faq_block("Common Roofing Questions from Phoenix Homeowners &amp; Businesses", [
    ("How do I know if I need a roof repair or full replacement?", "It depends on the roof's age, how widespread the damage is, and how many prior repairs it's had. A free inspection gives you a clear, honest recommendation with cost comparisons for both options."),
    ("Do you provide free estimates?", "Yes, every inspection and estimate is free with no obligation, whether you need an emergency repair or are planning a full re-roof."),
    ("What areas do you serve?", "We serve the greater Phoenix metro, including Scottsdale, Tempe, Mesa, Chandler, Gilbert, Glendale, Peoria, Surprise, and Ahwatukee."),
    ("Are you licensed and insured?", "Yes. Roofing work is performed by Sun & Shield Construction and Roofing, a licensed and fully insured Arizona roofing contractor, Arizona ROC #366348. You can verify the license at roc.az.gov."),
])}

{cta_band()}
"""
    html = page(
        current_path="/index.html",
        title=f"{SITE_NAME} | Roofing Company in Phoenix, AZ",
        meta_description=f"Licensed Phoenix, AZ roofing contractor. Roof repair, full replacement, residential, commercial & spray foam roofing. Free estimates — call {PHONE_DISPLAY}.",
        canonical="/index.html",
        breadcrumb="Home",
        body_html=body,
        schema_json=local_business_schema(),
    )
    write("index.html", html)


def build_about():
    body = f"""
<div class="page-hero">
  <div class="container">
    <div class="breadcrumbs"><a href="/index.html">Home</a> / About</div>
    <span class="eyebrow" style="color:#ff9a56;">About Us</span>
    <h1>Locally Owned Roofing Contractor Serving the Phoenix Valley</h1>
    <p class="lead" style="max-width:640px;">Licensed and fully insured — built around honest estimates and roofing systems that actually hold up in Arizona heat.</p>
  </div>
</div>

<section>
  <div class="container two-col">
    <div>
      <h2>Our Story</h2>
      <p>{SITE_NAME} exists to give Phoenix-area homeowners and businesses a roofing contractor they can trust to explain their options honestly &mdash; not just upsell the most expensive system.</p>
      <p>Every roof we put our name on is installed and serviced by <strong>{POWERED_BY_HTML}</strong>, a licensed Arizona roofing contractor (Arizona {ROC_LICENSE}), fully insured and IKO certified. Their crews specialize in the roofing types that perform best in the Valley's climate: tile, shingle, metal, TPO/EPDM commercial systems, and spray foam (SPF) roofing.</p>
      <p>Every project starts with a real inspection and a written estimate, whether it's a single emergency leak repair or a full commercial re-roof.</p>
      <h2>Our Values</h2>
      <ul class="service-list">
        <li>Transparent, itemized estimates before any work begins</li>
        <li>Licensed and fully insured on every job</li>
        <li>Materials and techniques chosen for Arizona's climate, not generic defaults</li>
        <li>Clear communication from inspection through final walkthrough</li>
      </ul>
    </div>
    <div class="card" style="padding:32px;">
      <h3>Fast Facts</h3>
      <ul class="service-list">
        <li>Licensed Arizona roofing contractor &mdash; {ROC_LICENSE}</li>
        <li>Work performed by {POWERED_BY_HTML}</li>
        <li>Residential, commercial &amp; spray foam roofing</li>
        <li>Serving Phoenix, Scottsdale, Tempe, Mesa, Chandler, Gilbert &amp; more</li>
        <li>Free inspections and written estimates</li>
        <li>Storm damage &amp; insurance claim documentation support</li>
      </ul>
      <a href="/contact.html" class="btn">Request a Free Estimate</a>
    </div>
  </div>
</section>

{testimonials_block()}\n{credentials_block()}
{service_area_block()}
{cta_band("Have Questions About Your Roof?", "Reach out for a free inspection — no pressure, just a clear answer about what your roof needs.")}
"""
    html = page(
        current_path="/about.html",
        title=f"About {SITE_NAME} | Licensed AZ Roofing Contractor",
        meta_description=f"About {SITE_NAME} — a licensed, fully insured roofing contractor serving homes and businesses across the Phoenix metro.",
        canonical="/about.html",
        breadcrumb="About",
        body_html=body,
    )
    write("about.html", html)


def build_contact():
    body = f"""
<div class="page-hero">
  <div class="container">
    <div class="breadcrumbs"><a href="/index.html">Home</a> / Contact</div>
    <span class="eyebrow" style="color:#ff9a56;">Contact Us</span>
    <h1>Request Your Free Roofing Estimate</h1>
    <p class="lead" style="max-width:640px;">Call us directly or send your details below — a member of our team will follow up shortly.</p>
  </div>
</div>

<section>
  <div class="container two-col">
    <div>
      <h2>Get In Touch</h2>
      <p>📞 <a href="tel:{PHONE_TEL}">{PHONE_DISPLAY}</a> &mdash; call or text</p>
      <p>📝 Or send your details using the form &mdash; we typically reply within one business hour.</p>
      <p>📍 {ADDRESS_LINE}</p>
      <p>🕐 Monday&ndash;Saturday, 7:00 AM&ndash;6:00 PM &nbsp;|&nbsp; 24/7 emergency storm response</p>
      <p style="font-size:0.9rem;color:#6b7684;">Roofing work performed by {POWERED_BY_HTML}, Arizona {ROC_LICENSE}.</p>
      <h3 style="margin-top:32px;">Service Area</h3>
      <div class="chip-row">
        {"".join(f'<span class="chip">{a}, AZ</span>' for a in SERVICE_AREAS)}
      </div>
    </div>
    <div>
      {lead_form(heading="Send Us Your Project Details", compact=True)}
    </div>
  </div>
</section>
"""
    html = page(
        current_path="/contact.html",
        title=f"Contact Us | Free Roofing Estimate in Phoenix, AZ",
        meta_description=f"Contact {SITE_NAME} for a free roofing estimate. Call {PHONE_DISPLAY} or request a callback online. Serving the greater Phoenix, AZ metro.",
        canonical="/contact.html",
        breadcrumb="Contact",
        body_html=body,
    )
    write("contact.html", html)


def build_404():
    """Custom 404. Kept useful rather than apologetic: a dead link is still a
    visitor with a roof problem, so give them the phone number and a way on."""
    service_links = "\n        ".join(
        f'<li><a href="{href}">{label}</a></li>' for href, label in SERVICE_LINKS
    )
    city_links = "\n        ".join(
        f'<li><a href="{city_path(slug)}">{CITIES[slug]["name"]} Roofing</a></li>' for slug in CITIES
    )
    body = f"""
<div class="page-hero">
  <div class="container">
    <span class="eyebrow" style="color:#ff9a56;">Error 404</span>
    <h1>That page isn't here</h1>
    <p class="lead" style="max-width:620px;">The link may be out of date or mistyped. If your roof
    needs attention right now, call us &mdash; that's faster than hunting for the right page.</p>
    <div class="hero-cta-row">
      <a href="tel:{PHONE_TEL}" class="btn">Call {PHONE_DISPLAY}</a>
      <a href="/index.html" class="btn btn-outline">Back to Home</a>
    </div>
  </div>
</div>

<section>
  <div class="container two-col">
    <div>
      <h2>Roofing Services</h2>
      <ul class="service-list">
        {service_links}
      </ul>
    </div>
    <div>
      <h2>Service Areas</h2>
      <ul class="service-list">
        {city_links}
      </ul>
    </div>
  </div>
</section>
"""
    html = page(
        current_path="/404.html",
        title=f"Page Not Found | {SITE_NAME}",
        meta_description="That page could not be found. Call us or browse our roofing services and Phoenix-area service areas.",
        canonical="/404.html",
        breadcrumb="404",
        body_html=body,
        robots="noindex, follow",   # a 404 must never be indexed
    )
    write("404.html", html)


def build_robots_and_sitemap():
    robots = f"""User-agent: *
Allow: /

Sitemap: {DOMAIN}/sitemap.xml
"""
    write("robots.txt", robots)

    urls = (["/index.html", "/about.html", "/contact.html"]
            + [s["nav"] for s in SERVICES.values()]
            + [city_path(slug) for slug in CITIES])
    entries = "\n".join(
        f"  <url>\n    <loc>{DOMAIN}{u}</loc>\n  </url>" for u in urls
    )
    sitemap = f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{entries}
</urlset>
"""
    write("sitemap.xml", sitemap)


# ===========================================================================
# CITY LANDING PAGES
#
# These target "[city] roofing company / roof repair" searches. The hard part
# is NOT duplicating content: Google treats near-identical city pages as
# "doorway pages" and can suppress the whole set. So every page below is built
# around a genuinely different fact about that city's housing stock.
#
# The anchor is median year built (2024 American Community Survey via NAHB,
# reported Apr 2026), because roof age follows housing age directly:
#     Gilbert 2003 | Chandler 1997 | Mesa 1989 | Glendale 1986 | Tempe 1984
#
# Why that matters in Arizona: concrete tile lasts 40-50 years, but the
# underlayment beneath it only lasts ~20-25 years in this heat. So a Gilbert
# roof is hitting its FIRST underlayment failure right now, while a Tempe roof
# is on its third cycle and far more likely to be flat/low-slope foam work.
# Same company, five materially different sales conversations.
# ===========================================================================

CURRENT_YEAR = 2026

CITIES = {
    "gilbert": {
        "name": "Gilbert",
        "median_year": 2003,
        "title": "Gilbert AZ Roofing Company | Tile Underlayment Experts",
        "meta": "Gilbert AZ roofing company specializing in tile underlayment replacement, roof repair and re-roofs. HOA tile matching. Free estimates.",
        "h1": "Roofing Company in Gilbert, AZ",
        "lead": "Gilbert's tile roofs are hitting the age where the underlayment fails long before the tile does. That's the job we do most here.",
        "intro": [
            "Gilbert grew up fast. The median Gilbert home was built in <strong>2003</strong> &mdash; the newest housing stock of any major East Valley city outside Queen Creek &mdash; which means most of the town went up during a concrete tile boom that ran from the late 1990s through the housing crash.",
            "That timing matters more than most homeowners realize. Concrete tile itself lasts 40 to 50 years, but the underlayment beneath it &mdash; the membrane that actually keeps water out of your house &mdash; only lasts about 20 to 25 years in Arizona heat. A Gilbert roof built in 2003 is sitting right in the middle of that failure window, even though the tile on top still looks essentially new from the street.",
            "So the most common call we get in Gilbert isn't a roof replacement at all. It's a <strong>tile lift-and-relay</strong>: we carefully remove and stack your existing tile, replace the failed underlayment and any damaged decking underneath, then re-lay the same tile back down. It costs a fraction of a full replacement and buys another two decades.",
        ],
        "bullets_head": "What we actually see on Gilbert roofs",
        "bullets": [
            "Underlayment failure on 1998&ndash;2008 tile roofs &mdash; far and away the most common Gilbert job",
            "Cracked and slipped concrete tile from heat cycling and foot traffic",
            "HOA-compliant tile matching for Val Vista Lakes, Morrison Ranch, Seville and similar communities",
            "Leaks at valleys, headwalls, and skylight flashing rather than in the open field of the roof",
            "Ridge and hip mortar deterioration on original builder installations",
            "Monsoon and wind damage on Gilbert's newer two-story stock",
        ],
        "neighborhoods": ["Val Vista Lakes", "Agritopia", "Morrison Ranch", "Power Ranch",
                           "Seville", "The Islands", "Cooley Station", "Higley Groves"],
        "focus_services": ["/services/residential-roofing.html", "/services/roof-repair.html",
                            "/services/roof-replacement-installation.html"],
        "faqs": [
            ("My Gilbert tile roof looks perfect from the street. Why would it need any work?",
             "Because you're looking at the tile, and the tile is almost never the problem. Tile is a rain shield with a 40-50 year life; the underlayment below it is the actual waterproofing layer and it only lasts about 20-25 years here. On a typical Gilbert home built in the early 2000s, the tile has decades left and the underlayment is at or past the end of its service life. The first symptom is usually a ceiling stain after a heavy monsoon, by which point water has already been getting into the decking for a while."),
            ("What does a tile lift-and-relay cost in Gilbert?",
             "Industry pricing in the Phoenix metro generally runs from about $5,000 to $12,000 and up, driven mostly by roof size, roof pitch, and how much decking underneath turns out to be damaged. It is substantially cheaper than a full tile replacement because your existing tile is reused. We give you a written, itemized number after inspecting the roof, and we tell you if you don't need the work yet."),
            ("Will you match the tile my HOA requires?",
             "Yes. Gilbert has a high concentration of HOA communities with specific approved tile profiles and colors, and matching them is routine for us. In a lift-and-relay your original tile goes back on, so the match is exact by definition &mdash; we only source replacement tile for the pieces that broke."),
            ("How long will my roof be torn apart?",
             "A residential lift-and-relay typically runs three to seven days: a day or two to remove and stack tile, a day to inspect and repair decking, a day or two for new underlayment, then two to three days to re-lay the tile. Your roof is never left open overnight without protection."),
        ],
    },
    "chandler": {
        "name": "Chandler",
        "median_year": 1997,
        "title": "Chandler AZ Roofing | Residential & Commercial Roofers",
        "meta": "Chandler AZ roofing contractor: tile underlayment replacement, re-roofs, repairs and commercial flat roofing on the Price Corridor.",
        "h1": "Roofing Company in Chandler, AZ",
        "lead": "Chandler roofs are typically about 29 years old &mdash; past the point where an original underlayment is still doing its job.",
        "intro": [
            "The median Chandler home was built in <strong>1997</strong>, which puts a typical Chandler roof at roughly 29 years old today. In Arizona that is meaningfully past the 20-to-25-year service life of tile underlayment, so most Chandler homeowners we talk to are either due for underlayment replacement or are already living on borrowed time with the original builder material.",
            "Chandler is really two roofing markets in one city. The older core around Historic Downtown and Arizona Avenue carries 1980s and earlier housing where shingle replacement and full re-roofs dominate. The southern build-out &mdash; Ocotillo, Fulton Ranch, Layton Lakes &mdash; is late-1990s and 2000s tile, which is the classic lift-and-relay profile.",
            "There's also a commercial side here that most Valley cities don't have to the same degree. The Price Corridor's concentration of office, tech, and industrial buildings means a lot of low-slope TPO and modified bitumen roofs, and those need a completely different maintenance rhythm than a house does.",
        ],
        "bullets_head": "What we handle most in Chandler",
        "bullets": [
            "Underlayment replacement on 1990s tile roofs that are now past service life",
            "Original 1990s asphalt shingle roofs well beyond their expected lifespan",
            "Commercial TPO, EPDM, and low-slope service along the Price Corridor",
            "Leaks around rooftop solar penetrations &mdash; solar is widespread on Chandler homes",
            "Ponding water on low-slope patio covers and room additions",
            "Monsoon wind damage and displaced tile on two-story stock",
        ],
        "neighborhoods": ["Ocotillo", "Fulton Ranch", "Andersen Springs", "Layton Lakes",
                           "Historic Downtown Chandler", "Circle G Ranches", "Clemente Ranch"],
        "focus_services": ["/services/commercial-roofing.html", "/services/roof-replacement-installation.html",
                            "/services/roof-repair.html"],
        "faqs": [
            ("My Chandler house is from the late 1990s. Is the roof due?",
             "Statistically, yes &mdash; or very close. Tile underlayment in Arizona runs about 20 to 25 years, and a 1997 home is at 29. If nobody has replaced the underlayment since the house was built, it is past due regardless of how the tile looks. An inspection settles it in one visit; we'd rather tell you it has three years left than sell you work you don't need yet."),
            ("Do you service commercial buildings in the Price Corridor?",
             "Yes. We work on TPO, EPDM, modified bitumen, and coated low-slope systems on office, retail, and industrial properties, and we schedule around tenant operations including after-hours and weekend work where the building requires it. We also offer scheduled inspection programs, which on a commercial flat roof is nearly always cheaper than reacting to leaks."),
            ("We have solar panels. Can the roof still be redone?",
             "Yes, but it takes coordination. The panels have to be removed before the roof work and reinstalled afterward, and that's typically handled by your solar installer or a licensed solar contractor rather than the roofing crew, since it involves the electrical connections and often your warranty. We'll sequence our schedule around that and tell you upfront what it adds to the timeline."),
        ],
    },
    "mesa": {
        "name": "Mesa",
        "median_year": 1989,
        "title": "Mesa AZ Roofing Company | Roof Replacement & Repair",
        "meta": "Mesa AZ roofing contractor for roof replacement, repair and storm damage. Serving Dobson Ranch, Las Sendas, Eastmark and 55+ communities.",
        "h1": "Roofing Company in Mesa, AZ",
        "lead": "Mesa spans four decades of housing, and a lot of it is on its second roof already. Which cycle you're in changes the whole conversation.",
        "intro": [
            "The median Mesa home was built in <strong>1989</strong>, making the typical Mesa roof around 37 years old. Practically speaking that means most Mesa homes have already been re-roofed once, usually somewhere in the 2000s &mdash; and roofs installed then are now reaching the end of their own service life. A lot of our Mesa work is second-cycle replacement rather than first.",
            "Mesa is also the most varied city we serve. It runs from 1970s and 1980s shingle-era neighborhoods in the west and central areas, through established master-planned communities like Dobson Ranch and Red Mountain Ranch, out to genuinely new construction in Eastmark. Add the large 55-plus communities, which have their own association requirements and scheduling expectations, and there's no single Mesa roof.",
            "Because Mesa's older stock is largely asphalt shingle rather than tile, the decision point here is often material rather than repair-versus-replace: whether to put shingle back down or move to tile or a coated system for the longer life and lower attic heat.",
        ],
        "bullets_head": "Common Mesa roofing work",
        "bullets": [
            "Second-cycle roof replacement on homes re-roofed in the 2000s",
            "Original 1970s and 1980s shingle roofs long past their service life",
            "Shingle-to-tile and shingle-to-shingle re-roof decisions, with real cost comparisons",
            "Work in 55+ communities with association approval and scheduling requirements",
            "Foam and reflective coating work on flat-roof and Santa Fe style homes in east Mesa",
            "Hail and wind damage documentation for insurance claims",
        ],
        "neighborhoods": ["Dobson Ranch", "Las Sendas", "Red Mountain Ranch", "Superstition Springs",
                           "Alta Mesa", "Eastmark", "Leisure World", "Historic West Mesa"],
        "focus_services": ["/services/roof-replacement-installation.html", "/services/residential-roofing.html",
                            "/services/foam-roofing.html"],
        "faqs": [
            ("My Mesa house was re-roofed in the 2000s. Is it really due again?",
             "Quite possibly. A shingle roof installed in, say, 2004 is 22 years old, and Arizona UV exposure shortens asphalt shingle life compared to milder climates &mdash; 15 to 25 years is a realistic range here rather than the 30 the packaging suggests. If your last re-roof was more than about 18 years ago, an inspection is worth doing even with no visible symptoms."),
            ("Do you work in 55+ communities like Leisure World?",
             "Yes. These communities typically have architectural approval requirements, specific material or color restrictions, and rules about work hours and crew access. We're used to submitting for approval and scheduling to fit the community's expectations rather than showing up and creating a problem."),
            ("Should I switch from shingle to tile?",
             "Sometimes, but not automatically. Tile costs more upfront and is heavier &mdash; some older homes need a structural check before taking the load. In exchange you get a much longer material life and better heat performance. On a home you plan to keep for 15+ years the math often favors tile; if you're selling in three years it usually doesn't. We'll price both so you're choosing with real numbers."),
        ],
    },
    "tempe": {
        "name": "Tempe",
        "median_year": 1984,
        "title": "Tempe AZ Roofing Company | Foam & Flat Roof Specialists",
        "meta": "Tempe AZ roofing contractor specializing in spray foam roofing for flat and low-slope homes, repairs and rental property service.",
        "h1": "Roofing Company in Tempe, AZ",
        "lead": "Tempe has the oldest housing of any city we serve, and a lot of it is flat or low-slope &mdash; which makes foam the default answer here more often than anywhere else in the Valley.",
        "intro": [
            "The median Tempe home was built in <strong>1984</strong>, tying Phoenix for the oldest housing stock in the metro and making the typical Tempe roof about 42 years old. Unlike the East Valley cities, Tempe is landlocked and fully built out &mdash; there is no new subdivision absorbing the average. The housing stock is what it is, and it keeps getting older.",
            "That age brings a specific kind of roof. Tempe carries a large share of mid-century ranch and post-war homes with flat or low-slope sections, and those roofs have often been patched repeatedly across three or four ownership changes. Layer upon layer of coating and patch material eventually stops being a roof and starts being archaeology.",
            "It's also why <strong>spray polyurethane foam</strong> comes up more in Tempe than anywhere else we work. On a low-slope roof, foam goes down seamless with no joints for water to find, adds real insulation value to a house that was built before anyone cared much about it, and can be recoated every several years instead of torn off and replaced. And with Tempe's large rental and investor market around ASU, an owner with several properties tends to care a lot about a roof that can be maintained rather than replaced.",
        ],
        "bullets_head": "What Tempe roofs usually need",
        "bullets": [
            "Spray foam (SPF) application and recoating on flat and low-slope mid-century homes",
            "Undoing years of patch-on-patch repairs on older flat roofs",
            "Third-cycle full replacement on roofs that have already been done twice",
            "Rental and multi-unit property service for ASU-area landlords and investors",
            "Material choices appropriate to the Borden Homes, Victory Acres, and Maple-Ashland historic areas",
            "Tile and shingle work in the newer South Tempe communities",
        ],
        "neighborhoods": ["The Lakes", "Warner Ranch", "Maple-Ashland", "Borden Homes",
                           "Victory Acres", "Escalante", "South Tempe", "Downtown Tempe"],
        "focus_services": ["/services/foam-roofing.html", "/services/roof-repair.html",
                            "/services/roof-replacement-installation.html"],
        "faqs": [
            ("Why does foam roofing come up so often in Tempe?",
             "Because of the housing stock. Tempe has an unusually high share of mid-century homes with flat or low-slope roofs, and foam is genuinely well suited to that geometry &mdash; it's sprayed on seamless, so there are no laps or seams for water to work into, and the reflective topcoat cuts how much heat the roof pushes into the house. It's also maintainable: you recoat it periodically rather than tearing it off, which is why it's popular with owners who hold property long term."),
            ("I own several rentals near ASU. Can you handle them together?",
             "Yes, and it's usually cheaper to do so. We can inspect multiple properties in one pass and give you a prioritized list &mdash; what needs work now, what can wait a season, and what's fine &mdash; so you're budgeting across the portfolio instead of reacting to whichever tenant calls first. Scheduling around tenant turnover is generally easiest between leases."),
            ("My house is in a Tempe historic district. Does that limit my options?",
             "It can. Tempe's historic districts have preservation guidelines that may affect visible roofing materials and profiles, so the right move is to confirm what's permitted before committing to a material. We'll work within whatever the district requires; just tell us during the inspection so we're pricing something you can actually get approved."),
        ],
    },
    "glendale": {
        "name": "Glendale",
        "median_year": 1986,
        "title": "Glendale AZ Roofing | Shingle Replacement & Storm Repair",
        "meta": "Glendale AZ roofing contractor. Shingle replacement, monsoon and storm damage repair, Arrowhead tile underlayment, Westgate commercial.",
        "h1": "Roofing Company in Glendale, AZ",
        "lead": "Almost half of Glendale's homes went up in the 1970s and 80s. Those are shingle-era roofs, and most are well past the end of the line.",
        "intro": [
            "Glendale's median home was built in <strong>1986</strong>, but the more useful number is the distribution: roughly <strong>23% of Glendale housing was built in the 1970s and another 23% in the 1980s</strong>. Nearly half the city predates 1990, which is a very different profile from the East Valley.",
            "Practically, that means Glendale is a shingle city more than a tile city. Homes from that era were largely built with asphalt shingle, and after 35 to 50 years of Arizona UV exposure those roofs are typically on their second or third replacement. The failure pattern is different too &mdash; granule loss, curling, and brittleness across the whole roof rather than a single leak you can chase down.",
            "North Glendale is the exception. Arrowhead Ranch and the communities around it went up in the 1990s and 2000s with tile, which puts them on the same underlayment clock as the East Valley. And the West Valley takes a real beating in monsoon season, so storm and haboob damage is a bigger share of our Glendale calls than it is elsewhere.",
        ],
        "bullets_head": "Typical Glendale roofing work",
        "bullets": [
            "Asphalt shingle replacement on 1970s and 1980s West Valley homes",
            "Tile underlayment replacement in Arrowhead Ranch and north Glendale",
            "Monsoon, haboob, and high-wind damage repair with insurance documentation",
            "Commercial roofing around Westgate and the sports and entertainment district",
            "Reflective coatings and attic ventilation on older, under-insulated homes",
            "Appropriate materials for the Catlin Court historic district",
        ],
        "neighborhoods": ["Arrowhead Ranch", "Sahuaro Ranch", "Catlin Court", "Westgate",
                           "Thunderbird", "Historic Downtown Glendale", "North Glendale"],
        "focus_services": ["/services/roof-replacement-installation.html", "/services/roof-repair.html",
                            "/services/commercial-roofing.html"],
        "faqs": [
            ("Half of Glendale's homes are 40+ years old. What does that mean for mine?",
             "If your home is from the 1970s or 1980s and still has asphalt shingle, it has almost certainly been replaced at least once already &mdash; and that replacement may itself now be aging out. The tell on an old shingle roof isn't usually a dramatic leak; it's granules in the gutters, shingles that curl at the edges, and brittleness that makes them crack when walked on. Those are whole-roof symptoms, and patching rarely makes sense at that point."),
            ("Do you handle storm damage insurance claims?",
             "We document them thoroughly, which is the part that actually matters. After a monsoon or wind event we photograph the damage, write an itemized estimate, and give you everything your carrier needs to evaluate the claim. We're not the insurance company and we can't promise what they'll approve, but well-documented wind and hail damage is commonly covered."),
            ("Can a new roof actually lower my APS or SRP bill?",
             "It can help, though it's rarely dramatic on its own. Reflective tile, a coated or foam roof, and properly functioning attic ventilation all reduce how much heat gets into your attic, which is one of the larger drivers of summer cooling load on older Glendale homes. The homes that see the biggest change are usually the ones that also had poor insulation or blocked ventilation &mdash; we look at all three during the inspection rather than just quoting the roof."),
        ],
    },
}


def city_path(slug):
    return f"/service-areas/{slug}-roofing.html"


def city_schema(city):
    import json
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "RoofingContractor",
        "name": f"{SITE_NAME} &mdash; {city['name']}, AZ".replace("&mdash;", "-"),
        "url": f"{DOMAIN}{city_path(city['slug'])}",
        "telephone": PHONE_TEL,
        "priceRange": "$$",
        "parentOrganization": {"@type": "Organization", "name": POWERED_BY},
        "address": {
            "@type": "PostalAddress",
            "addressLocality": city["name"],
            "addressRegion": "AZ",
            "addressCountry": "US"
        },
        "areaServed": {"@type": "City", "name": f"{city['name']}, Arizona"},
        "sameAs": [GOOGLE_BUSINESS_PROFILE] if GOOGLE_BUSINESS_PROFILE else [],
    }, indent=2)


def build_city_page(slug):
    city = dict(CITIES[slug], slug=slug)
    name = city["name"]
    roof_age = CURRENT_YEAR - city["median_year"]
    canonical = city_path(slug)

    intro_html = "\n      ".join(f"<p>{p}</p>" for p in city["intro"])
    bullets_html = "\n      ".join(f"<li>{b}</li>" for b in city["bullets"])
    chips = "\n        ".join(f'<span class="chip">{n}</span>' for n in city["neighborhoods"])

    label_by_href = {href: label for href, label in SERVICE_LINKS}
    service_cards = "\n      ".join(
        f'''<div class="card">
          <h3><a href="{href}">{label_by_href[href]} in {name}</a></h3>
          <p>{SERVICES[href.split("/")[-1].replace(".html", "")]["lead"]}</p>
          <a href="{href}">Learn more &rarr;</a>
        </div>''' for href in city["focus_services"]
    )

    siblings = [s for s in CITIES if s != slug]
    sibling_links = " &nbsp;&middot;&nbsp; ".join(
        f'<a href="{city_path(s)}">{CITIES[s]["name"]} Roofing</a>' for s in siblings
    )

    body = f"""
<div class="page-hero">
  <div class="container">
    <div class="breadcrumbs"><a href="/index.html">Home</a> / <a href="/index.html#service-areas">Service Areas</a> / {name}</div>
    <span class="eyebrow" style="color:#ff9a56;">{name}, Arizona</span>
    <h1>{city['h1']}</h1>
    <p class="lead" style="max-width:680px;">{city['lead']}</p>
  </div>
</div>

<div class="stat-strip">
  <div class="container grid" style="grid-template-columns:repeat(3,1fr);">
    <div><div class="num">{city['median_year']}</div><div class="label">Median year a {name} home was built</div></div>
    <div><div class="num">~{roof_age} yrs</div><div class="label">Age of a typical {name} roof today</div></div>
    <div><div class="num">20&ndash;25</div><div class="label">Years tile underlayment lasts in AZ heat</div></div>
  </div>
</div>

<section>
  <div class="container two-col">
    <div>
      {intro_html}
      <h3 style="margin-top:28px;">{city['bullets_head']}</h3>
      <ul class="service-list">
      {bullets_html}
      </ul>
      <a href="/contact.html" class="btn">Get a Free {name} Roof Inspection</a>
    </div>
    <div>
      {lead_form(heading=f"Free {name} Roofing Estimate")}
    </div>
  </div>
</section>

<section class="alt">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">{name} Neighborhoods</span>
      <h2>Areas of {name} We Work In</h2>
      <p>If your neighborhood isn't listed, we almost certainly still serve it &mdash; just ask.</p>
    </div>
    <div class="chip-row" style="justify-content:center;">
        {chips}
    </div>
  </div>
</section>

<section>
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">Services</span>
      <h2>What We Do Most in {name}</h2>
    </div>
    <div class="grid grid-3">
      {service_cards}
    </div>
  </div>
</section>

{faq_block(f"{name} Roofing Questions", city['faqs'])}

<section>
  <div class="container" style="text-align:center;">
    <span class="eyebrow">Nearby</span>
    <h2>We Also Serve</h2>
    <p style="color:#495057;">{sibling_links}</p>
  </div>
</section>

{cta_band(f"Need a Roofer in {name}?",
          f"Free inspection, written estimate, and an honest answer about whether your {name} roof actually needs work yet.")}
"""

    html = page(
        current_path=canonical,
        title=city["title"],
        meta_description=city["meta"],
        canonical=canonical,
        breadcrumb=name,
        body_html=body,
        schema_json=[city_schema(city), faq_schema(city["faqs"], canonical)],
    )
    write(canonical.lstrip("/"), html)


if __name__ == "__main__":
    build_home()
    for slug in SERVICES:
        build_service_page(slug)
    for slug in CITIES:
        build_city_page(slug)
    build_about()
    build_contact()
    build_404()
    build_robots_and_sitemap()
    print("\nSite generated successfully.")
