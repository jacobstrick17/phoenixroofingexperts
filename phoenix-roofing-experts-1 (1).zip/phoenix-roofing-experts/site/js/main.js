// Phoenix Roofing Experts — shared site behavior

document.addEventListener("DOMContentLoaded", function () {
  // Mobile nav toggle
  var toggle = document.querySelector(".menu-toggle");
  var nav = document.querySelector("nav.primary-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      nav.classList.toggle("open");
    });
  }

  // Wire up every form with data-lead-form to Supabase
  var forms = document.querySelectorAll("[data-lead-form]");
  forms.forEach(function (form) {
    form.addEventListener("submit", handleLeadSubmit);
  });
});

async function handleLeadSubmit(e) {
  e.preventDefault();
  var form = e.target;
  var statusEl = form.querySelector("[data-form-status]");
  var submitBtn = form.querySelector('button[type="submit"]');
  var cfg = window.SUPABASE_CONFIG;

  var name = form.querySelector('[name="name"]').value.trim();
  var email = form.querySelector('[name="email"]') ? form.querySelector('[name="email"]').value.trim() : "";
  var phone = form.querySelector('[name="phone"]') ? form.querySelector('[name="phone"]').value.trim() : "";
  var city = form.querySelector('[name="city"]') ? form.querySelector('[name="city"]').value.trim() : "Phoenix";
  var service = form.querySelector('[name="service"]') ? form.querySelector('[name="service"]').value : "";
  var message = form.querySelector('[name="message"]') ? form.querySelector('[name="message"]').value.trim() : "";

  // Phone is required: the site publishes no email address, so a lead without a
  // phone number would be one we have no fast way to reach.
  if (!name || !phone) {
    setStatus(statusEl, "Please enter your name and a phone number so we can reach you.", true);
    return;
  }

  var notesParts = [];
  if (service) notesParts.push("Interested in: " + service);
  if (message) notesParts.push(message);
  var notes = notesParts.join(" — ");

  var payload = {
    name: name,
    email: email || null,
    phone: phone || null,
    city: city || "Phoenix",
    address: null,
    source: "website",
    notes: notes || null
  };

  if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = "Sending..."; }

  try {
    var res = await fetch(cfg.url + "/rest/v1/contacts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": cfg.anonKey,
        "Authorization": "Bearer " + cfg.anonKey,
        "Prefer": "return=minimal"
      },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      var errText = await res.text();
      throw new Error(errText || "Request failed");
    }

    form.reset();
    setStatus(statusEl, "Thanks! Your request has been received — a member of our team will call you back shortly.", false);
  } catch (err) {
    console.error(err);
    setStatus(statusEl, "Something went wrong sending your request. Please call us directly instead.", true);
  } finally {
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = submitBtn.getAttribute("data-default-text") || "Get My Free Estimate"; }
  }
}

function setStatus(el, msg, isError) {
  if (!el) return;
  el.textContent = msg;
  el.className = isError ? "error" : "success";
  el.id = "form-status";
}
